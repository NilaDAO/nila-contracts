// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";

/// @dev minimal mintable ERC-20 + permit for tests
contract ERC20PermitMock is ERC20Permit {
    constructor(
        string memory name,
        string memory symbol,
        address initialHolder,
        uint256 initialSupply
    ) ERC20(name, symbol) ERC20Permit(name) {
        _mint(initialHolder, initialSupply);
    }
}
