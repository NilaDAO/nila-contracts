// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts-upgradeable/token/ERC1155/extensions/ERC1155SupplyUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/cryptography/EIP712Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/utils/Strings.sol";

/**
 * @title FoodTokenUpgradeable
 * @notice Upgradeable ERC‑1155 where each token ID represents 1 kg of a specific crop batch.
 *         Metadata tuple (cropType, variety, harvestDate) → deterministic ID via keccak256.
 *         Minting authorised through EIP‑712 Vouchers signed by whitelisted `oracleSigners`.
 * 
 * 
 * 
 * v1:      On event CropMinted: we index cropCode harvestDate and to (max 3 allowed) instead of cropcode, variety and landid
 */
contract FoodTokenUpgradeable is
    Initializable,
    OwnableUpgradeable,
    PausableUpgradeable,
    ReentrancyGuardUpgradeable,
    ERC1155SupplyUpgradeable,
    EIP712Upgradeable,
    UUPSUpgradeable
{
    using ECDSA for bytes32;
    using Strings for uint256;

    // ------------------------------------------------------------------
    // Constants & Storage
    // ------------------------------------------------------------------
   
    // --- Layout: allocate bits within uint256 ID ---
    // bit layout: [ cropCode (16 bits) | varietyCode (16 bits) | landTitleId (32 bits) | harvestDate (32 bits) ]
    uint8 private constant SHIFT_HARVEST    = 0;
    uint8 private constant SHIFT_LANDTITLE  = SHIFT_HARVEST + 32;
    uint8 private constant SHIFT_VARIETY    = SHIFT_LANDTITLE + 32;
    uint8 private constant SHIFT_CROP       = SHIFT_VARIETY + 16;

    // --- Voucher TypeHash ---
    bytes32 private constant VOUCHER_TYPEHASH = keccak256(
        "MintVoucher(address to,uint16 cropCode,uint16 varietyCode,uint32 landTitleId,uint32 harvestDate,uint256 quantity)"
    );

    mapping(address => bool)   public oracleSigners;    // authorised voucher signers

    struct Voucher {
        address to;
        uint16  cropCode;
        uint16  varietyCode;  
        uint32  landTitleId; 
    }

    // ─────────────── events ───────────────
    event CropMinted( uint256 indexed cropCode,uint256 varietyCode, uint256 landTitleId,uint256 indexed harvestDate,address indexed to,uint256 quantity);

    // ------------------------------------------------------------------
    // Initializer
    // ------------------------------------------------------------------
    /// @notice Initialize the contract with an IPFS base URI for metadata
    /// @param baseURI The IPFS base URI (e.g., "ipfs://QmYourCID/{id}.json")
    /// @param initialOracle The initial oracle signer address
    function initialize(string memory baseURI, address initialOracle)
        public initializer
    {
        __Ownable_init(initialOracle);
        __Pausable_init();
        __ReentrancyGuard_init();
        __ERC1155_init(baseURI);
        __ERC1155Supply_init();
        __EIP712_init("FoodToken", "1");
        __UUPSUpgradeable_init();

        oracleSigners[initialOracle] = true;
    }

    // ------------------------------------------------------------------
    // Admin
    // ------------------------------------------------------------------

    function setOracleSigner(address signer, bool allowed) external onlyOwner {
        oracleSigners[signer] = allowed;
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ------------------------------------------------------------------
    // Minting via Voucher
    // ------------------------------------------------------------------

    function _hashVoucher(Voucher memory v) private view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(
                VOUCHER_TYPEHASH,
                v.to,
                v.cropCode,
                v.varietyCode,
                v.landTitleId
            )));
    }

    function mintWithVoucher(Voucher calldata v, bytes calldata sig, uint256 harvestDate, uint256 quantity)
        external
        whenNotPaused
        nonReentrant
    {
        require(msg.sender == v.to, "caller != voucher.to");
        bytes32 digest = _hashVoucher(v);
        address signer = digest.recover(sig);
        require(oracleSigners[signer], "unauthorised signer");

        uint256 id = (uint256(v.cropCode)   << SHIFT_CROP)
                   | (uint256(v.varietyCode) << SHIFT_VARIETY)
                   | (uint256(v.landTitleId) << SHIFT_LANDTITLE)
                   |  uint256(harvestDate);

        _mint(v.to, id, quantity, "");
        emit CropMinted(v.cropCode, v.varietyCode, v.landTitleId, harvestDate, v.to, quantity);
    }
    /**
     * @notice Update the base URI for all token types
     * @dev baseURI must include the `{id}` substitution marker
     * @param newBaseURI the new base URI (e.g. `ipfs://QmNewCID/{id}.json`)
     */
    function setBaseURI(string memory newBaseURI) external onlyOwner {
        _setURI(newBaseURI);
    }

    /// @notice hash helper for off‑chain voucher signing tools
    function getVoucherDigest(Voucher calldata v) external view returns (bytes32) {
        return _hashVoucher(v);
    }

    // --- Decoders ---
    function decodeCrop(uint256 id) public pure returns (uint16) {
        return uint16(id >> SHIFT_CROP);
    }
    function decodeVariety(uint256 id) public pure returns (uint16) {
        return uint16(id >> SHIFT_VARIETY);
    }
    function decodeLandTitle(uint256 id) public pure returns (uint32) {
        return uint32(id >> SHIFT_LANDTITLE);
    }
    function decodeHarvestDate(uint256 id) public pure returns (uint32) {
        return uint32(id >> SHIFT_HARVEST);
    }

    function uri(uint256 id) public view override returns (string memory) {
        return super.uri(id);
    }
    // ------------------------------------------------------------------
    // Metadata & Views
    // ------------------------------------------------------------------

    // ------------------------------------------------------------------
    // UUPS
    // ------------------------------------------------------------------

    function _authorizeUpgrade(address newImpl) internal override onlyOwner {}

    // ------------------------------------------------------------------
    // Storage gap
    // ------------------------------------------------------------------

    uint256[46] private __gap;
}
