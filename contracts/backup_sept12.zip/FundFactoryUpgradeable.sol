// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/**
 * FundFactory – v2.1  (UUPS‑upgradeable, Planting‑aware)
 * -----------------------------------------------------
 * • Keeps the original registry mapping:  union ⇒ FundInfo[]
 * • Deploys upgrade‑safe proxy instances of **PlantingFundUpgradeable**.
 * • The factory itself is UUPS‑upgradeable (Ownable).
 */
import "./InputFundUpgradeable.sol";
import "./PlantingFundUpgradeable.sol";
import { Initializable }            from "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import { OwnableUpgradeable }       from "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import { UUPSUpgradeable }          from "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import { ERC1967Proxy }             from "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";

contract FundFactoryUpgradeable is Initializable, OwnableUpgradeable, UUPSUpgradeable {
    /*──────────────────────────────────────────────────────────
     * Data structures
     *────────────────────────────────────────────────────────*/

    struct FundInfo {
        address fund;          // proxy address
        string  name;          // human‑readable fund name
        string  contractname;  // implementation label (e.g. "PlantingFundUpgradeable")
    }

    /// @notice unionAddress ⇒ array of funds it utilises
    mapping(address => FundInfo[]) private fundsByOwner;

    /// Implementations (upgradeable so DAO can roll to new logic)
    address public inputFundImpl;      // InputFund implementation
    address public plantingFundImpl;   // PlantingFund implementation

    /// all fund proxy addresses
    address[] public allFunds;
    /*──────────────────────────────────────────────────────────
     *  Events
     *────────────────────────────────────────────────────────*/
    event FundCreated           (address indexed _union, address proxy, address fund);
    event GlobalFundCreated     (address proxy, address fund);
    event FundRegistered        (address indexed union, address indexed fund, string name);
    event PlantingImplUpdated   (address impl);
    event InputImplUpdated      (address impl);
    event FundLogicSet          (string id, address impl);
    event FundRemoved           (address indexed _union, address indexed fund);

    /*──────────────────────────────────────────────────────────
     *  Initializer (UUPS)
     *────────────────────────────────────────────────────────*/

    function initialize(address _inputImpl, address _plantingImpl) public initializer {
        __Ownable_init(_msgSender());
        __UUPSUpgradeable_init();
        inputFundImpl     = _inputImpl;          // may be zero if unused
        plantingFundImpl  = _plantingImpl;       // must be set for createPlantingFund
        emit PlantingImplUpdated(_plantingImpl);
    }

    /*──────────────────────────────────────────────────────────
     *  External: create a PlantingFund
     *────────────────────────────────────────────────────────*/

    function createPlantingFund(
        address _treasury,
        address _oracleSigner

        ) external returns (address proxyAddr) {
        /* -------------------------------------------------------
        1) resolve implementation address for this fund‑type
        ------------------------------------------------------- */
        address impl = plantingFundImpl;
        require(impl != address(0), "fundtype not registered");
        require(_treasury != address(0), "treasury = zero");
    
        /* -------------------------------------------------------
        2) encode initializer calldata
        ------------------------------------------------------- */
        bytes memory initData = abi.encodeWithSelector(
            PlantingFundUpgradeable.initialize.selector,
            _treasury,
            _oracleSigner,
            address(this)
        );

        /* -------------------------------------------------------
        3) deploy proxy pointing to the resolved implementation
        ------------------------------------------------------- */
        ERC1967Proxy proxy = new ERC1967Proxy(plantingFundImpl, initData);
        proxyAddr = address(proxy);

        /* -------------------------------------------------------
        4) bookkeeping & event
        ------------------------------------------------------- */
        allFunds.push(proxyAddr);
        emit GlobalFundCreated(proxyAddr, impl);
    }

    /*──────────────────────────────────────────────────────────
     *  External: create a InputFund for specific union!
     *────────────────────────────────────────────────────────*/

    function createInputFund(
        address[] calldata _tokens,
        string  calldata _fundName,
        address         _oracleSigner,
        uint16          _baseRateBP,
        address         _union
        ) external returns (address proxyAddr) {
        /* -------------------------------------------------------
        1) resolve implementation address for this fund‑type
        ------------------------------------------------------- */
        address impl = inputFundImpl;
        require(impl != address(0), "fundtype not registered");

        /* -------------------------------------------------------
        2) encode initializer calldata
        ------------------------------------------------------- */
        bytes memory initData = abi.encodeWithSelector(
            InputFundUpgradeable.initialize.selector,
            _fundName,
            _tokens,
            _oracleSigner,
            _baseRateBP,
            _union
        );

        /* -------------------------------------------------------
        3) deploy proxy pointing to the resolved implementation
        ------------------------------------------------------- */
        ERC1967Proxy proxy = new ERC1967Proxy(impl, initData);
        proxyAddr = address(proxy);

        /* -------------------------------------------------------
        4) bookkeeping & event
        ------------------------------------------------------- */
        allFunds.push(proxyAddr);
        fundsByOwner[_union].push(FundInfo({ fund: proxyAddr, name: _fundName, contractname: 'InputFundUpgradeable' }));
        emit FundCreated(_union, proxyAddr, impl);
    } 

    /// @notice fund owner has the ability to remove the contract from the mapping
    function removeFund(address fund) external {
        require(fund != address(0), "zero addr");
        
        address fundOwner = OwnableUpgradeable(fund).owner(); 
        require(msg.sender == fundOwner, "caller is not the fund owner");
        
        FundInfo[] storage list = fundsByOwner[fundOwner];
        uint256 len = list.length;
        for (uint256 j; j < len; ++j) {
            if (list[j].fund == fund) {
                list[j] = list[len - 1];
                list.pop();
                break;
            }
        }    
        emit FundRemoved(fundOwner, fund);
    }

    /// @notice factory owner has the ability to add a new input fund implementation
    function setInputFundImpl(address _impl) external onlyOwner {
    require(_impl != address(0), "impl = zero");
    inputFundImpl = _impl;
    emit InputImplUpdated(_impl);
}
    /// @notice factory owner has the ability to add a new planting fund implementation
    function setPlantingFundImpl(address _impl) external onlyOwner {
    require(_impl != address(0), "impl = zero");
    plantingFundImpl = _impl;
    emit PlantingImplUpdated(_impl);
}

    /*──────────────────────────────────────────────────────────
     *  Called by unions to self‑register global fund instances (e.g. Plantingfund)
     *────────────────────────────────────────────────────────*/

    function registerUnion(
        address _union,
        address _fund,
        string  calldata _name,
        string  calldata _contractname
    ) external {
        require(msg.sender == _union, "unauthorized, only union owner can register at factory");
        require(_fund != address(0), "fund = zero");
        fundsByOwner[_union].push(FundInfo({ fund: _fund, name: _name, contractname: _contractname }));
        emit FundRegistered(_union, _fund, _name);
    }

    /*──────────────────────────────────────────────────────────
     *  Views
     *────────────────────────────────────────────────────────*/
    /// @notice Alias for front-end: get all funds for a given union
    function getFundsByOwner(address _union) external view returns (FundInfo[] memory) {
        return fundsByOwner[_union];
    }

    /// @notice Returns all fund proxies
    function getAllFunds() external view returns (address[] memory) {
        return allFunds;
    }


    /*──────────────────────────────────────────────────────────
     *  UUPS authorization
     *────────────────────────────────────────────────────────*/

    function _authorizeUpgrade(address newImplementation) internal override onlyOwner {}
}
