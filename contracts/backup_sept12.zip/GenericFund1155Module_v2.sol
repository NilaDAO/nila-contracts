// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import "@openzeppelin/contracts/token/ERC1155/IERC1155.sol";
import "@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol";

interface IGenericFundCore {
    function viewer() external view returns (address);
    function isOracleSigner(address) external view returns (bool);
    function mintJuniorFromQuote(
        address unionAddr, address token, bytes32 loanType, address investor, uint256 quoteAmount
    ) external returns (uint256);
}

interface IViewer {
    function recoverQuote1155Signer(
        address coreAddr,
        address unionAddr,
        address token,
        bytes32 loanType,
        address investor,
        address collection,
        uint256 id,
        uint256 amount1155,
        uint256 quoteAmount,
        uint256 nonce,
        uint40  expiry,
        bytes calldata sig
    ) external view returns (address);
}

contract GenericFund1155Module_V2 is Ownable, ReentrancyGuard, ERC1155Holder {
    // ---- storage ----
    IGenericFundCore public immutable core;

    // allowlist: union => token => loanType => collection => id => allowed
    mapping(address => mapping(address => mapping(bytes32 => mapping(address => mapping(uint256 => bool))))) public is1155Allowed;
    event ERC1155AllowedSet(address indexed unionAddr, address indexed token, bytes32 indexed loanType, address collection, uint256 id, bool allowed);

    // nonces to prevent replay per investor
    mapping(address => mapping(uint256 => bool)) public used1155Nonces;

    struct Lot {
        address owner;
        address unionAddr;
        address token;
        bytes32 loanType;
        address collection;
        uint256 id;
        uint256 amount1155;
        uint256 sharesMinted;  // shares created from quote
        bool    active;
    }
    uint256 public nextLotId;
    mapping(uint256 => Lot) public lots;

    // events
    event Invested1155(address indexed unionAddr, address indexed investor, address indexed token, bytes32 loanType, address collection, uint256 id, uint256 amount1155, uint256 quoteAmount, uint256 shares, uint256 lotId);

    // errors
    error ZeroAmount();
    error QuoteExpired();
    error NonceUsed();
    error NotAllowed();
    error NotCore();
    error LotInvalid();
    error LotMismatch();

    modifier onlyCore() {
        if (msg.sender != address(core)) revert NotCore();
        _;
    }

    constructor(address core_, address initialOwner) Ownable(initialOwner) {
        require(core_ != address(0), "core=0");
        core = IGenericFundCore(core_);
    }

    // ---- admin ----
    function set1155Allowed(address unionAddr, address token, bytes32 loanType, address collection, uint256 id, bool allowed) external onlyOwner {
        is1155Allowed[unionAddr][token][loanType][collection][id] = allowed;
        emit ERC1155AllowedSet(unionAddr, token, loanType, collection, id, allowed);
    }

    // ---- user flow: invest ERC1155 into a junior bucket via oracle quote ----
    function investJunior1155(
        address unionAddr,
        address token,
        bytes32 loanType,
        address collection,
        uint256 id,
        uint256 amount1155,
        uint256 quoteAmount,
        uint256 nonce,
        uint40  expiry,
        bytes calldata oracleSig
        ) external nonReentrant {
        if (amount1155 == 0 || quoteAmount == 0) revert ZeroAmount();
        if (!is1155Allowed[unionAddr][token][loanType][collection][id]) revert NotAllowed();
        if (block.timestamp > expiry) revert QuoteExpired();
        if (used1155Nonces[msg.sender][nonce]) revert NonceUsed();

        // ✅ verify oracle quote using the Viewer (OZ v4 domain shape),
        //    but with Core address as the verifyingContract
        address viewerAddr = core.viewer();
        address signer = IViewer(viewerAddr).recoverQuote1155Signer(
            address(core),            // verifyingContract in the domain
            unionAddr,
            token,
            loanType,
            msg.sender,               // investor
            collection,
            id,
            amount1155,
            quoteAmount,
            nonce,
            expiry,
            oracleSig
        );
        if (!core.isOracleSigner(signer)) revert NotAllowed();
        used1155Nonces[msg.sender][nonce] = true;

        // escrow 1155
        IERC1155(collection).safeTransferFrom(msg.sender, address(this), id, amount1155, "");

        // mint junior shares in core based on quote
        uint256 shares = core.mintJuniorFromQuote(unionAddr, token, loanType, msg.sender, quoteAmount);

        // record lot for in-kind redemption
        uint256 lotId = ++nextLotId;
        lots[lotId] = Lot({
            owner: msg.sender,
            unionAddr: unionAddr,
            token: token,
            loanType: loanType,
            collection: collection,
            id: id,
            amount1155: amount1155,
            sharesMinted: shares,
            active: true
        });

        emit Invested1155(unionAddr, msg.sender, token, loanType, collection, id, amount1155, quoteAmount, shares, lotId);
    }

    // ---- called by Core on request-withdraw validation ----
    function validateLot(
        address owner,
        address unionAddr,
        address token,
        bytes32 loanType,
        uint256 shares,
        uint256 lotId
    ) external view returns (bool) {
        Lot storage L = lots[lotId];
        if (!L.active) return false;
        if (L.owner != owner) return false;
        if (L.unionAddr != unionAddr || L.token != token || L.loanType != loanType) return false;
        if (L.sharesMinted != shares) return false;
        return true;
    }

    // ---- called by Core during claimWithdraw for in-kind path ----
    function redeemLot(
        address to,
        uint256 lotId,
        address unionAddr,
        address token,
        bytes32 loanType,
        uint256 shares
    ) external onlyCore {
        Lot storage L = lots[lotId];
        if (!(L.active && L.owner == to)) revert LotInvalid();
        if (L.unionAddr != unionAddr || L.token != token || L.loanType != loanType) revert LotMismatch();
        if (L.sharesMinted != shares) revert LotMismatch();

        IERC1155(L.collection).safeTransferFrom(address(this), to, L.id, L.amount1155, "");
        L.active = false;
    }
}
