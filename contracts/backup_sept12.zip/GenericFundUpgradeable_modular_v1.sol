// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
 * GenericFundUpgradeable — v1.4
 */

import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

//  ----------- Custom math libary -----------
import { GenericFundMathLib } from "./GenericFundMathLib.sol";

//  ----------- ERC1155 functions -----------
interface IERC1155Module {
    function validateLot(address owner, address unionAddr, address token, bytes32 loanType, uint256 shares, uint256 lotId) external view returns (bool);
    function redeemLot(address to, uint256 lotId, address unionAddr, address token, bytes32 loanType, uint256 shares) external;
}

interface IGenericFundViewer {
    // use the version you implemented (struct or fields). Here’s the *fields* version to avoid type coupling:
    function recoverVoucherSigner(address core,address borrower, address union_, address token, uint256 maxAmount, uint16 minRateBP, uint256 nonce, bytes32 loanType, bytes32 paramsHash, bytes calldata sig) external view returns (address);
    function recoverQuote1155Signer(address core, address unionAddr, address token, bytes32 loanType, address investor, address collection, uint256 id,uint256 amount1155, uint256 quoteAmount, uint256 nonce, uint40 expiry,bytes calldata sig) external view returns (address);
}

//  ----------- ////////////////////// -----------
//  ----------- GenericFundUpgradeable -----------
//  ----------- ////////////////////// -----------

contract GenericFundUpgradeable_V1 is  Initializable,
                                    OwnableUpgradeable,
                                    PausableUpgradeable,
                                    ReentrancyGuardUpgradeable,
                                    UUPSUpgradeable
{

    // ───────── constants ─────────
    uint256 private constant RAY  = 1e27;
    uint256 private constant YEAR = 365 days;
    uint256 private constant CARRYOVER_WINDOW = 22 days; // tolerance
    uint16  private constant TREASURY_FEE_BP = 100; // 1%
    uint256 private constant MIN_UNBONDING = 14 days;

    enum Tranche { JUNIOR, SENIOR }

    // ───────── custom errors ─────────
    error ZeroAmount();
    error UnionInactive();
    error NotOracleOrLeader();
    error MarketEmpty();
    error SeniorEmpty();
    error InsufficientUnlocked();
    error InsufficientLiquidity();
    error NotOwner();
    error NotAvailable();
    error AlreadyClaimed();
    error LoanNotExist();
    error LoanClosed();
    error BadKink();
    error MaxLessThanBase();
    error TreasuryZero();
    error BadOracleSig();
    error RateBelowMin();
    error AmountTooHigh();
    error ParamsMismatch();
    error HardStop();
    error BufferInsufficient();
    error CapZero();
    error CapExceeded();
    error RateBelowModel();
    error InterestNotSettled();
    error NotBorrowerOrAdmin();
    error ERC1155ModuleNotSet();
    error LotMismatch();
    error LoanExists();
    error MaturityAlreadySet();
    error SafetyBPGt10000();

    // ───────── access ─────────
    mapping(address => bool) public oracleSigners;      // oracle keys
    mapping(address => address) public unionLeader;     // union ⇒ leader

    modifier onlyOracleOrLeader(address unionAddr) {
        if (!(oracleSigners[msg.sender] || msg.sender == unionLeader[unionAddr])) revert NotOracleOrLeader();
        _;
    }

    // ───────── config ─────────
    address public treasury;
    address public erc1155Module;
    address public viewer;

    event ERC1155ModuleSet(address indexed module);

    modifier onlyERC1155Module() {
        if (msg.sender != erc1155Module) revert ERC1155ModuleNotSet();
        _;
    }

    function setERC1155Module(address module_) external onlyOwner {
        erc1155Module = module_;
        emit ERC1155ModuleSet(module_);
    }

    // Senior capacity included in cap per union/token
    mapping(address => mapping(address => uint256)) public seniorCap; // union ⇒ token ⇒ cap

    // Rate model
    struct RateParams {
        uint16 baseRateBP;
        uint16 kinkUtilBP; // 0..10000
        uint16 slope1BP;
        uint16 slope2BP;
        uint16 maxRateBP;
    }
    mapping(address => RateParams) public rateParams; // token ⇒ params

    // ───────── accounting ─────────
    struct MarketLite { 
        uint128 supplyIndex; 
        uint256 totalShares; 
        uint256 totalBorrows; 
        uint256 maxDeposited; 
    }

    struct InvestorLite { 
        uint256 shares; 
        uint128 entryIndex; 
        uint128 unclaimed; 
        uint256 lockedShares; 
    }

    struct Market {
        uint128 supplyIndex;   // RAY (init 1e27)
        uint128 borrowIndex;   // reserved
        uint256 totalShares;
        uint256 totalBorrows;  // junior type-buckets only
        uint256 maxDeposited;  // historical max (for cap)
    }

    struct InvestorInfo {
        uint256 shares;
        uint128 entryIndex;
        uint128 unclaimed;
        uint256 lockedShares;  // in pending unbond requests
    }

    struct Loan {
        address borrower;
        address token;
        uint128 principal;
        uint16  rateBP;
        uint40  drawdownTs;
        uint40  harvestTs;     // unused (storage spacer)
        uint40  maturityTs;
        uint128 repaid;
        uint128 interestPaid;
        bool    liquidated;
        bool    defaulted;
        bytes32 loanType;
        bytes32 paramsHash;
    }

    struct Voucher {
        address borrower;
        address union;
        address token;
        uint256 maxAmount;
        uint16  minRateBP;
        uint256 nonce;
        bytes32 loanType;
        bytes32 paramsHash;
    }

    struct Union {
        string  name;
        bool    active;

        // Junior markets per {token, loanType}
        mapping(address => mapping(bytes32 => Market)) juniorByType;
        mapping(address => mapping(bytes32 => mapping(address => InvestorInfo))) investorsByType;
        mapping(bytes32 => Loan) loans;
    }

    mapping(address => mapping(address => uint256)) private unionBorrowsAgg; // union => token => total borrows
    mapping(address => Union) private unions;
    mapping(address => string) public unionLocation;
    mapping(address => bytes32[]) public loansByBorrower;

    // Aggregated cap base per {union, token}
    mapping(address => mapping(address => uint256)) private unionCapBase;

    // Senior markets
    mapping(address => Market) private seniorMarkets;         // token ⇒ market
    mapping(address => mapping(address => InvestorInfo)) private seniorInvestors; // token ⇒ investor ⇒ info

    // ───────── unbonding withdrawals ─────────
    struct WithdrawRequest {
        Tranche tranche;
        address investor;
        address unionAddr; // junior only
        address token;
        bytes32 loanType;  // junior only
        uint256 shares;
        uint256 erc1155LotId; // for in-kind via module
        bool    inKind1155;
        uint40  requestedAt;
        bool    claimed;

        // Liquidity buffer tracking:
        uint256 principalAtRequest;        // fixed at request time (0 if in-kind1155)
        bool    wasEverClaimableAccounted; // set when promoted into claimable counter
    }
    uint256 public nextWithdrawRequestId;
    mapping(uint256 => WithdrawRequest) private withdrawRequests;

    // Per-token liquidity buffer state
    mapping(address => uint16)  public bufferSafetyBP;       // e.g., 1000 = +10% on claimables
    mapping(address => uint256) public bufferSafetyFloor;    // absolute cushion
    mapping(address => uint256) public hardStopClaimable;    // 0 = disabled

    mapping(address => uint256) public pendingPrincipalTotal;      // sum of principalAtRequest for all open requests
    mapping(address => uint256) public pendingPrincipalClaimable;  // subset whose unbonding finished

    mapping(address => uint256[]) private withdrawQueueByToken;    // token ⇒ requestIds (chronological)
    mapping(address => uint256)   private withdrawQueueHead;       // index into queue

    // ───────── events ─────────
    event TreasuryUpdated(address indexed newTreasury);
    event OracleSignerUpdated(address indexed signer, bool allowed);
    event UnionLeaderSet(address indexed unionAddr, address indexed leader);
    event UnionActivated(address indexed unionAddr, string location);
    event UnionDeactivated(address indexed unionAddr);

    // Investments
    event Invested(Tranche tranche, address indexed unionAddr, address indexed investor, address indexed token, bytes32 loanType, uint256 amount, uint256 shares);

    // Unbonding
    event WithdrawRequested(uint256 indexed requestId, Tranche tranche, address indexed investor, address indexed token, address unionAddr, bytes32 loanType, uint256 shares, bool inKind1155, uint256 erc1155LotId, uint40 availableAt, uint256 principalAtRequest);
    event WithdrawClaimed(uint256 indexed requestId, uint256 principalOut, uint256 interestOut, bool inKind1155);

    // Loans
    event LoanClaimed(address indexed unionAddr, bytes32 indexed loanId, address indexed borrower, address token, uint256 principal, uint16 rateBP, bytes32 loanType, bytes32 paramsHash);
    event LoanAcceptedLowRate(address indexed unionAddr, bytes32 indexed loanId, uint16 rateBP);
    event MaturityReported(address indexed unionAddr, bytes32 indexed loanId, uint40 maturityTs);
    event LoanRepaid(address indexed unionAddr, bytes32 indexed loanId, address indexed payer, uint256 amount, uint256 interestPaidNow, uint256 principalPaidNow);
    event LoanDefaulted(address indexed unionAddr, bytes32 indexed loanId, uint256 juniorLossApplied, uint256 seniorLossApplied);
    event LoanRolledOver(address indexed unionAddr, bytes32 indexed loanId, uint16 newRateBP, uint40 newDrawdownTs);
    event LoanTransferred(address indexed unionAddr, bytes32 indexed loanId, address indexed newBorrower, uint16 newRateBP, uint40 newDrawdownTs);
    event LoanParams(bytes32 indexed loanId, bytes params);

    // Admin
    event RateParamsUpdated(address indexed token, uint16 baseRateBP, uint16 kinkUtilBP, uint16 slope1BP, uint16 slope2BP, uint16 maxRateBP);
    event SeniorCapUpdated(address indexed unionAddr, address indexed token, uint256 capAmount);
    event BufferParamsSet(address indexed token, uint16 safetyBP, uint256 safetyFloor);
    event HardStopClaimableSet(address indexed token, uint256 amount);
    event BufferSync(address indexed token, uint256 advanced, uint256 newHead, uint256 claimableNow);
    event ViewerSet(address indexed viewer);

    //  ----------- ////////////////////// -----------
    //  -----------     INIT | UPGRADE   -----------
    //  ----------- ////////////////////// -----------

    function initialize(address _treasury, address _oracleSigner) public initializer {
        if (_treasury == address(0)) revert TreasuryZero();
        __Ownable_init(_oracleSigner);
        __Pausable_init();
        __ReentrancyGuard_init();
        __UUPSUpgradeable_init();

        treasury = _treasury;
        emit TreasuryUpdated(_treasury);
    }

    function _authorizeUpgrade(address /*impl*/) internal override onlyOwner {}

    //  ----------- /////////////////////////////////////////// -----------
    //  -----------     ADMIN | GOVERNANCE (SETTERS BY OWNER)   -----------
    //  ----------- /////////////////////////////////////////// -----------
    
    function setTreasury(address newTreasury) external onlyOwner {
        if (newTreasury == address(0)) revert TreasuryZero();
        treasury = newTreasury;
        emit TreasuryUpdated(newTreasury);
    }

    function setOracleSigner(address signer, bool allowed) external onlyOwner {
        oracleSigners[signer] = allowed;
        emit OracleSignerUpdated(signer, allowed);
    }

    function setUnionLeader(address unionAddr, address leader) external onlyOwner {
        unionLeader[unionAddr] = leader;
        emit UnionLeaderSet(unionAddr, leader);
    }

    function activateUnion(address unionAddr, string calldata location) external onlyOwner {
        unions[unionAddr].active = true;
        unionLocation[unionAddr] = location;
        emit UnionActivated(unionAddr, location);
    }

    function deactivateUnion(address unionAddr) external onlyOwner {
        unions[unionAddr].active = false;
        emit UnionDeactivated(unionAddr);
    }

    function setSeniorCap(address unionAddr, address token, uint256 capAmount) external onlyOwner {
        seniorCap[unionAddr][token] = capAmount;
        emit SeniorCapUpdated(unionAddr, token, capAmount);
    }

    function setRateParams(
        address token,
        uint16 baseRateBP,
        uint16 kinkUtilBP,
        uint16 slope1BP,
        uint16 slope2BP,
        uint16 maxRateBP
        ) external onlyOwner {
        if (kinkUtilBP == 0 || kinkUtilBP > 10000) revert BadKink();
        if (maxRateBP < baseRateBP) revert MaxLessThanBase();
        rateParams[token] = RateParams(baseRateBP, kinkUtilBP, slope1BP, slope2BP, maxRateBP);
        emit RateParamsUpdated(token, baseRateBP, kinkUtilBP, slope1BP, slope2BP, maxRateBP);
    }

    function setViewer(address v) external onlyOwner {
        viewer = v;
        emit ViewerSet(v);
    }

    function setBufferParams(address token, uint16 safetyBP, uint256 safetyFloor) external onlyOwner {
        if (safetyBP > 10000) revert SafetyBPGt10000();
        bufferSafetyBP[token] = safetyBP;
        bufferSafetyFloor[token] = safetyFloor;
        emit BufferParamsSet(token, safetyBP, safetyFloor);
    }

    /////////// ----  SAFE ERC20 LOW-LEVEL ------ ///////////////

    function _safeTransfer(address token, address to, uint256 amount) private {
        assembly ("memory-safe") {
            let ptr := mload(0x40)
            mstore(ptr, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
            mstore(add(ptr, 4), to)
            mstore(add(ptr, 36), amount)
            let ok := call(gas(), token, 0, ptr, 68, 0, 32)
            if iszero(ok) { revert(0, 0) }
            switch returndatasize()
            case 0 { }
            case 32 {
                returndatacopy(ptr, 0, 32)
                if iszero(mload(ptr)) { revert(0, 0) }
            }
            default { revert(0, 0) }
        }
    }

    function _safeTransferFrom(address token, address from, address to, uint256 amount) private {
        assembly ("memory-safe") {
            let ptr := mload(0x40)
            mstore(ptr, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
            mstore(add(ptr, 4), from)
            mstore(add(ptr, 36), to)
            mstore(add(ptr, 68), amount)
            let ok := call(gas(), token, 0, ptr, 100, 0, 32)
            if iszero(ok) { revert(0, 0) }
            switch returndatasize()
            case 0 { }
            case 32 {
                returndatacopy(ptr, 0, 32)
                if iszero(mload(ptr)) { revert(0, 0) }
            }
            default { revert(0, 0) }
        }
    }

    function _balanceOf(address token, address account) private view returns (uint256 bal) {
        assembly ("memory-safe") {
            let ptr := mload(0x40)
            mstore(ptr, 0x70a0823100000000000000000000000000000000000000000000000000000000)
            mstore(add(ptr, 4), account)
            if iszero(staticcall(gas(), token, ptr, 36, 0, 32)) { revert(0, 0) }
            returndatacopy(ptr, 0, 32)
            bal := mload(ptr)
        }
    }


    // ───────── tranche invest / withdraw / claim ─────────
    function _investJunior(
        address unionAddr,
        address token,
        bytes32 loanType,
        address investor,
        uint256 amount
        ) internal returns (uint256 sharesOut) {
        Union storage u = unions[unionAddr];
        if (!u.active) revert UnionInactive();

        Market storage m = u.juniorByType[token][loanType];
        if (m.supplyIndex == 0) {
            m.supplyIndex = uint128(RAY);
            // removed: tokenSeen / unionTokens / loanTypesByToken registration
        }

        sharesOut = GenericFundMathLib.toShares(amount, m.supplyIndex);
        unchecked { m.totalShares += sharesOut; }

        uint256 underlyingAfter = GenericFundMathLib.toUnderlying(m.totalShares, m.supplyIndex);
        if (underlyingAfter > m.maxDeposited) {
            uint256 delta = underlyingAfter - m.maxDeposited;
            m.maxDeposited = underlyingAfter;
            unchecked { unionCapBase[unionAddr][token] += delta; }
        }

        InvestorInfo storage info = u.investorsByType[token][loanType][investor];
        _accrueInvestor(info, m.supplyIndex);
        unchecked { info.shares += sharesOut; }

        emit Invested(Tranche.JUNIOR, unionAddr, investor, token, loanType, amount, sharesOut);
    }

    /// @notice Standard ERC20 invest (unchanged)
    function invest(Tranche tranche, address unionAddr, address token, bytes32 loanType, uint256 amount)
        external whenNotPaused nonReentrant
        {
        if (amount == 0) revert ZeroAmount();
       _safeTransferFrom(token, msg.sender, address(this), amount);

        if (tranche == Tranche.JUNIOR) {
            _investJunior(unionAddr, token, loanType, msg.sender, amount);
        } else {
            // Senior logic remains unchanged
            Market storage s = seniorMarkets[token];
            if (s.supplyIndex == 0) {
                s.supplyIndex = uint128(RAY);
            }

            uint256 shares = GenericFundMathLib.toShares(amount, s.supplyIndex);
            unchecked { s.totalShares += shares; }

            uint256 underlyingAfter = GenericFundMathLib.toUnderlying(s.totalShares, s.supplyIndex);
            if (underlyingAfter > s.maxDeposited) s.maxDeposited = underlyingAfter;

            InvestorInfo storage info = seniorInvestors[token][msg.sender];
            _accrueInvestor(info, s.supplyIndex);
            unchecked { info.shares += shares; }

            emit Invested(Tranche.SENIOR, address(0), msg.sender, token, bytes32(0), amount, shares);
        }
    }

    /// @notice Called by the ERC1155 module after it has escrowed the ERC1155 and verified the oracle quote.
    function mintJuniorFromQuote(
        address unionAddr,
        address token,
        bytes32 loanType,
        address investor,
        uint256 quoteAmount
        ) external whenNotPaused nonReentrant onlyERC1155Module returns (uint256 sharesOut) {
        if (quoteAmount == 0) revert ZeroAmount();
        return _investJunior(unionAddr, token, loanType, investor, quoteAmount);
    }


    // ── Unbonding (request → claim) with buffer tracking ──
    function requestWithdrawJunior(
        address unionAddr,
        address token,
        bytes32 loanType,
        uint256 shares,
        bool inKind1155,
        uint256 erc1155LotId
        ) external whenNotPaused nonReentrant returns (uint256 reqId) {
        if (shares == 0) revert ZeroAmount();
        Union storage u = unions[unionAddr];
        if (!u.active) revert UnionInactive();
        Market storage m = u.juniorByType[token][loanType];
        if (m.supplyIndex == 0) revert MarketEmpty();

        InvestorInfo storage info = u.investorsByType[token][loanType][msg.sender];
        if (shares > info.shares - info.lockedShares) revert InsufficientUnlocked();

        if (inKind1155) {
            if (erc1155Module == address(0)) revert ERC1155ModuleNotSet();
            bool ok = IERC1155Module(erc1155Module).validateLot(msg.sender, unionAddr, token, loanType, shares, erc1155LotId);
            if (!ok) revert LotMismatch();
        } else {
            if (erc1155LotId != 0) revert LotMismatch();
        }

        _accrueInvestor(info, m.supplyIndex);
        info.lockedShares += shares;

        uint256 principalAtReq = inKind1155 ? 0 : GenericFundMathLib.toUnderlying(shares, m.supplyIndex);

        unchecked { nextWithdrawRequestId++; reqId = nextWithdrawRequestId; }
        withdrawRequests[reqId] = WithdrawRequest({
            tranche: Tranche.JUNIOR,
            investor: msg.sender,
            unionAddr: unionAddr,
            token: token,
            loanType: loanType,
            shares: shares,
            erc1155LotId: erc1155LotId,
            inKind1155: inKind1155,
            requestedAt: uint40(block.timestamp),
            claimed: false,
            principalAtRequest: principalAtReq,
            wasEverClaimableAccounted: false
        });

        if (principalAtReq > 0) {
            pendingPrincipalTotal[token] += principalAtReq;
            withdrawQueueByToken[token].push(reqId);
        }

        emit WithdrawRequested(
            reqId, Tranche.JUNIOR, msg.sender, token, unionAddr, loanType, shares, inKind1155, erc1155LotId,
            uint40(block.timestamp + MIN_UNBONDING), principalAtReq
        );
    }

    function requestWithdrawSenior(address token, uint256 shares)
        external whenNotPaused nonReentrant returns (uint256 reqId)
        {
        if (shares == 0) revert ZeroAmount();
        Market storage s = seniorMarkets[token];
        if (s.supplyIndex == 0) revert SeniorEmpty();

        InvestorInfo storage info = seniorInvestors[token][msg.sender];
        if (shares > info.shares - info.lockedShares) revert InsufficientUnlocked();

        _accrueInvestor(info, s.supplyIndex);
        info.lockedShares += shares;

        uint256 principalAtReq = GenericFundMathLib.toUnderlying(shares, s.supplyIndex);

        reqId = ++nextWithdrawRequestId;
        withdrawRequests[reqId] = WithdrawRequest({
            tranche: Tranche.SENIOR,
            investor: msg.sender,
            unionAddr: address(0),
            token: token,
            loanType: bytes32(0),
            shares: shares,
            erc1155LotId: 0,
            inKind1155: false,
            requestedAt: uint40(block.timestamp),
            claimed: false,
            principalAtRequest: principalAtReq,
            wasEverClaimableAccounted: false
        });

        pendingPrincipalTotal[token] += principalAtReq;
        withdrawQueueByToken[token].push(reqId);

        emit WithdrawRequested(
            reqId, Tranche.SENIOR, msg.sender, token, address(0), bytes32(0), shares, false, 0,
            uint40(block.timestamp + MIN_UNBONDING), principalAtReq
        );
    }

    function claimWithdraw(uint256 requestId) external whenNotPaused nonReentrant {
        WithdrawRequest storage R = withdrawRequests[requestId];
        if (R.claimed) revert AlreadyClaimed();
        if (R.investor != msg.sender) revert NotOwner();
        if (block.timestamp < uint256(R.requestedAt) + MIN_UNBONDING) revert NotAvailable();

        uint256 principalOut = 0;
        uint256 interestOut = 0;

        // Reduce buffer counters (safe regardless of claimable-accounted state)
        if (R.principalAtRequest > 0) {
            pendingPrincipalTotal[R.token] = pendingPrincipalTotal[R.token] >= R.principalAtRequest
                ? pendingPrincipalTotal[R.token] - R.principalAtRequest
                : 0;

            if (R.wasEverClaimableAccounted) {
                pendingPrincipalClaimable[R.token] = pendingPrincipalClaimable[R.token] >= R.principalAtRequest
                    ? pendingPrincipalClaimable[R.token] - R.principalAtRequest
                    : 0;
            }
        }

        if (R.tranche == Tranche.JUNIOR) {
            Union storage u = unions[R.unionAddr];
            Market storage m = u.juniorByType[R.token][R.loanType];
            InvestorInfo storage info = u.investorsByType[R.token][R.loanType][msg.sender];

            _accrueInvestor(info, m.supplyIndex);

            // pro-rata interest payout on redeemed shares
            interestOut = info.shares == 0 ? 0 : (uint256(info.unclaimed) * R.shares) / info.shares;
            if (interestOut > 0) {
                info.unclaimed -= uint128(interestOut);
                _safeTransfer(R.token, msg.sender, interestOut);
            }

            if (info.lockedShares < R.shares) revert InsufficientUnlocked();
            info.lockedShares -= R.shares;
            info.shares -= R.shares;

            if (R.inKind1155) {
                if (erc1155Module == address(0)) revert ERC1155ModuleNotSet();
                IERC1155Module(erc1155Module).redeemLot(msg.sender, R.erc1155LotId, R.unionAddr, R.token, R.loanType, R.shares);
            } else {
                principalOut = GenericFundMathLib.toUnderlying(R.shares, m.supplyIndex);
                uint256 bal = _balanceOf(R.token, address(this));
                if (bal < principalOut) revert InsufficientLiquidity();
                _safeTransfer(R.token, msg.sender, principalOut);
                unchecked { m.totalShares -= R.shares; }
            }

        } else {
            Market storage s = seniorMarkets[R.token];
            InvestorInfo storage info = seniorInvestors[R.token][msg.sender];

            _accrueInvestor(info, s.supplyIndex);

            interestOut = info.shares == 0 ? 0 : (uint256(info.unclaimed) * R.shares) / info.shares;
            if (interestOut > 0) {
                info.unclaimed -= uint128(interestOut);
                _safeTransfer(R.token, msg.sender, interestOut);
            }

            if (info.lockedShares < R.shares) revert InsufficientUnlocked();
            info.lockedShares -= R.shares;
            info.shares -= R.shares;

            principalOut = GenericFundMathLib.toUnderlying(R.shares, s.supplyIndex);
            uint256 bal = _balanceOf(R.token, address(this));
            if (bal < principalOut) revert InsufficientLiquidity();
            _safeTransfer(R.token, msg.sender, principalOut);
            unchecked { s.totalShares -= R.shares; }
        }

        R.claimed = true;
        emit WithdrawClaimed(requestId, principalOut, interestOut, R.inKind1155);
    }

    function aggregateBorrowsForUnionToken(address unionAddr, address token) public view returns (uint256) {
        return unionBorrowsAgg[unionAddr][token];
    }

    // Example applyLoss (with cast fix):
    function _applyLossToMarket(Market storage m, uint256 loss) private returns (uint256 applied) {
        if (loss == 0 || m.supplyIndex == 0 || m.totalShares == 0) return 0;
        uint256 underlying = GenericFundMathLib.toUnderlying(m.totalShares, m.supplyIndex);
        if (underlying == 0) return 0;
        uint256 newIdx256;
        (applied, newIdx256) = GenericFundMathLib.haircutIndex(m.supplyIndex, underlying, loss);
        m.supplyIndex = uint128(newIdx256);
        return applied;
    }

    function _accrueInvestor(InvestorInfo storage info, uint256 currentSupplyIndex) private {
        if (info.shares == 0) { info.entryIndex = uint128(currentSupplyIndex); return; }
        if (currentSupplyIndex <= info.entryIndex) { info.entryIndex = uint128(currentSupplyIndex); return; }
        uint256 deltaIndex = currentSupplyIndex - info.entryIndex; // RAY
        uint256 pending    = (info.shares * deltaIndex) / RAY;
        info.unclaimed    += uint128(pending);
        info.entryIndex    = uint128(currentSupplyIndex);
    }


    function _creditInterestTranches(address unionAddr, address token, bytes32 loanType, uint256 interest) private {
        if (interest == 0) return;

        uint256 fee = (interest * TREASURY_FEE_BP) / 10_000;
        if (fee > 0) _safeTransfer(token, treasury, fee);
        uint256 toLenders = interest - fee;
        if (toLenders == 0) return;

        uint256 toSenior = toLenders / 2;
        uint256 toJunior = toLenders - toSenior;

        // SENIOR — index bump only
        if (toSenior > 0) {
            Market storage s = seniorMarkets[token];
            if (s.totalShares == 0) {
                _safeTransfer(token, treasury, toSenior);
            } else {
                uint256 d = (toSenior * RAY) / s.totalShares;
                s.supplyIndex = uint128(uint256(s.supplyIndex) + d);
            }
        }

        // JUNIOR (matching type) — index bump only
        if (toJunior > 0) {
            Union storage u = unions[unionAddr];
            Market storage m = u.juniorByType[token][loanType];
            if (m.totalShares == 0) {
                _safeTransfer(token, treasury, toJunior);
            } else {
                uint256 d = (toJunior * RAY) / m.totalShares;
                m.supplyIndex = uint128(uint256(m.supplyIndex) + d);

                // keep your maxDeposited/capBase bump
                uint256 underAfter = GenericFundMathLib.toUnderlying(m.totalShares, m.supplyIndex);
                if (underAfter > m.maxDeposited) {
                    uint256 delta = underAfter - m.maxDeposited;
                    m.maxDeposited = underAfter;
                    unionCapBase[unionAddr][token] += delta;
                }
            }
        }
    }

    // ───────── liquidity buffer: sync & view ─────────
    /// @notice Promote finished unbond requests (by timestamp) into claimable set; bounded by maxIter.
    function syncPendingClaimable(address token, uint256 maxIter) external {
        _syncPendingClaimable(token, maxIter);
    }

    function _syncPendingClaimable(address token, uint256 maxIter) internal {
        uint256[] storage Q = withdrawQueueByToken[token];
        uint256 head = withdrawQueueHead[token];
        uint256 advanced = 0;

        while (head < Q.length && advanced < maxIter) {
            uint256 reqId = Q[head];
            WithdrawRequest storage R = withdrawRequests[reqId];

            // If already accounted or claimed, advance head and continue
            if (R.wasEverClaimableAccounted || R.claimed) {
                unchecked { head++; advanced++; }
                continue;
            }

            uint256 availableAt = uint256(R.requestedAt) + MIN_UNBONDING;
            if (block.timestamp < availableAt) break;

            // promote into claimable
            if (R.principalAtRequest > 0) {
                pendingPrincipalClaimable[token] += R.principalAtRequest;
            }
            R.wasEverClaimableAccounted = true;

            unchecked { head++; advanced++; }
        }

        if (advanced > 0) {
            withdrawQueueHead[token] = head;
            emit BufferSync(token, advanced, head, pendingPrincipalClaimable[token]);
        }
    }

    //  ----------- ////////////////////// -----------
    //  -----------     LOAN LIFE CYCLE   -----------
    //  ----------- ////////////////////// -----------

    function claimLoan(
        Voucher   calldata v,
        uint256   chosenAmount,
        uint16    chosenRateBP,
        bytes     calldata params,
        bytes     calldata sig
        ) external whenNotPaused nonReentrant {
        _claimLoanInternal(v, chosenAmount, chosenRateBP, params, sig, /*bypassMinRate=*/false, /*callerIsAdmin=*/false);
    }

    function acceptLowRateLoan(
        Voucher   calldata v,
        uint256   chosenAmount,
        uint16    chosenRateBP,
        bytes     calldata params,
        bytes     calldata sig
        ) external whenNotPaused nonReentrant onlyOracleOrLeader(v.union) {
        _claimLoanInternal(v, chosenAmount, chosenRateBP, params, sig, /*bypassMinRate=*/true, /*callerIsAdmin=*/true);
        bytes32 loanId = keccak256(abi.encode(v));
        emit LoanAcceptedLowRate(v.union, loanId, chosenRateBP);
    }

    function _claimLoanInternal(
        Voucher   calldata v,
        uint256   chosenAmount,
        uint16    chosenRateBP,
        bytes     calldata params,
        bytes     calldata sig,
        bool      bypassMinRate,
        bool      callerIsAdmin
        ) internal {
        if (!(msg.sender == v.borrower || callerIsAdmin)) revert NotBorrowerOrAdmin();
        if (!(chosenAmount > 0 && chosenAmount <= v.maxAmount)) revert AmountTooHigh();
        if (!bypassMinRate && !(chosenRateBP >= v.minRateBP)) revert RateBelowMin();
        if (keccak256(params) != v.paramsHash) revert ParamsMismatch();

        // oracle signature over voucher (via Viewer)
        address signer = IGenericFundViewer(viewer).recoverVoucherSigner(
            address(this),
            v.borrower, v.union, v.token, v.maxAmount, v.minRateBP, v.nonce, v.loanType, v.paramsHash,
            sig
        );
        if (!oracleSigners[signer]) revert BadOracleSig();

        bytes32 loanId = keccak256(abi.encode(v));
        Union storage u = unions[v.union];
        if (!u.active) revert UnionInactive();
        if (u.loans[loanId].drawdownTs != 0) revert LoanExists();

        // earmarked junior market must exist
        Market storage mJ = u.juniorByType[v.token][v.loanType];
        if (mJ.supplyIndex == 0) revert MarketEmpty();

        // sync buffer for this token (small bounded step)
        _syncPendingClaimable(v.token, 10);

        // buffer hard stop (optional)
        uint256 hs = hardStopClaimable[v.token];
        if (hs > 0 && !(pendingPrincipalClaimable[v.token] < hs)) revert HardStop();

        // buffer reserve requirement
        uint256 available = _balanceOf(v.token, address(this));

        uint256 requiredReserve = (
            pendingPrincipalClaimable[v.token] * (10000 + bufferSafetyBP[v.token])
        ) / 10000 + bufferSafetyFloor[v.token];
        
        if (!(available >= chosenAmount + requiredReserve)) revert BufferInsufficient();

        // borrow cap & rate model checks
        uint256 capBase = unionCapBase[v.union][v.token] + seniorCap[v.union][v.token];
        uint256 cap = 2 * capBase;
        if (!(cap > 0)) revert CapZero();

        if (!callerIsAdmin) {
            // The `cap` variable is already defined a few lines above this
            uint16 modelRate = GenericFundMathLib.quoteRateBP(
                GenericFundMathLib.RateParams(
                    rateParams[v.token].baseRateBP,
                    rateParams[v.token].kinkUtilBP,
                    rateParams[v.token].slope1BP,
                    rateParams[v.token].slope2BP,
                    rateParams[v.token].maxRateBP
                ),
                cap,
                aggregateBorrowsForUnionToken(v.union, v.token),
                chosenAmount
            );   
            if (!(chosenRateBP >= modelRate)) revert RateBelowModel();

        }

        // aggregate cap check
        if (!((aggregateBorrowsForUnionToken(v.union, v.token) + chosenAmount) <= cap)) revert CapExceeded();

        // write loan
        u.loans[loanId] = Loan({
            borrower:      v.borrower,
            token:         v.token,
            principal:     uint128(chosenAmount),
            rateBP:        chosenRateBP,
            drawdownTs:    uint40(block.timestamp),
            harvestTs:     0,
            maturityTs:    0,
            repaid:        0,
            interestPaid:  0,
            liquidated:    false,
            defaulted:     false,
            loanType:      v.loanType,
            paramsHash:    v.paramsHash
        });

        loansByBorrower[v.borrower].push(loanId);

        // move funds
        mJ.totalBorrows += chosenAmount;
        unionBorrowsAgg[v.union][v.token] += chosenAmount;
        _safeTransfer(v.token,v.borrower, chosenAmount);

        emit LoanClaimed(v.union, loanId, v.borrower, v.token, chosenAmount, chosenRateBP, v.loanType, v.paramsHash);
        emit LoanParams(loanId, params);
    }

    function repayLoan(address unionAddr, bytes32 loanId, uint256 amount) external whenNotPaused nonReentrant {
        if (amount == 0) revert ZeroAmount();
        Union storage u = unions[unionAddr];
        Loan storage ln = u.loans[loanId];
        if (ln.drawdownTs == 0) revert LoanNotExist();
        if (ln.liquidated || ln.defaulted) revert LoanClosed();

        address token = ln.token;
        Market storage mJ = u.juniorByType[token][ln.loanType];

        _safeTransferFrom(token, msg.sender, address(this), amount);

        uint40 currentTs = uint40(block.timestamp);
        uint40 endTs = ln.maturityTs == 0 ? currentTs : (currentTs < ln.maturityTs ? currentTs : ln.maturityTs);

        uint256 elapsed = uint256(endTs - ln.drawdownTs);
        uint256 totalInterestAccrued = (uint256(ln.principal) * ln.rateBP * elapsed) / (10_000 * YEAR);

        uint256 unpaidInterest = totalInterestAccrued > ln.interestPaid ? (totalInterestAccrued - ln.interestPaid) : 0;

        uint256 interestPayment = amount < unpaidInterest ? amount : unpaidInterest;
        uint256 principalRemaining = uint256(ln.principal) > ln.repaid ? (uint256(ln.principal) - ln.repaid) : 0;
        uint256 principalPayment = (amount > interestPayment)
            ? (amount - interestPayment > principalRemaining ? principalRemaining : (amount - interestPayment))
            : 0;

        if (interestPayment > 0) {
            ln.interestPaid += uint128(interestPayment);
            _creditInterestTranches(unionAddr, token, ln.loanType, interestPayment);
        }
        if (principalPayment > 0) {
            ln.repaid += uint128(principalPayment);
            mJ.totalBorrows -= principalPayment;
            unionBorrowsAgg[unionAddr][token] -= principalPayment;
        }

        bool principalCleared = ln.repaid >= ln.principal;
        if (principalCleared && ln.maturityTs != 0) {
            uint256 fullInterestToMaturity =
                (uint256(ln.principal) * ln.rateBP * uint256(ln.maturityTs - ln.drawdownTs)) / (10_000 * YEAR);
            if (ln.interestPaid >= fullInterestToMaturity) {
                ln.liquidated = true;
            }
        }

        emit LoanRepaid(unionAddr, loanId, msg.sender, amount, interestPayment, principalPayment);
    }

    function reportMaturity(address unionAddr, bytes32 loanId, uint40 maturityTs)
        external whenNotPaused onlyOracleOrLeader(unionAddr)
        {
        Loan storage ln = unions[unionAddr].loans[loanId];
        if (ln.drawdownTs == 0) revert LoanNotExist();
        if (ln.maturityTs != 0) revert MaturityAlreadySet();
        ln.maturityTs = maturityTs;
        emit MaturityReported(unionAddr, loanId, ln.maturityTs);
    }

    function defaultLoan(address unionAddr, bytes32 loanId, uint256 lossAmount)
        external whenNotPaused onlyOracleOrLeader(unionAddr)
        {if (lossAmount == 0) revert ZeroAmount();
        Union storage u = unions[unionAddr];
        Loan storage ln = u.loans[loanId];
        if (ln.drawdownTs == 0) revert LoanNotExist();
        if (ln.liquidated || ln.defaulted) revert LoanClosed();

        address token = ln.token;
        Market storage mJ = u.juniorByType[token][ln.loanType];

        // principal write-off
        uint256 principalRemaining = uint256(ln.principal) > ln.repaid ? (uint256(ln.principal) - ln.repaid) : 0;
        uint256 principalWriteoff = principalRemaining > 0 ? (lossAmount > principalRemaining ? principalRemaining : lossAmount) : 0;
        if (principalWriteoff > 0) {
            mJ.totalBorrows -= principalWriteoff;
            unionBorrowsAgg[unionAddr][token] -= principalWriteoff;
        }

        // haircut: Junior (matching type) then Senior
        uint256 remainingLoss = lossAmount;
        uint256 juniorApplied = _applyLossToMarket(mJ, remainingLoss);
        remainingLoss -= juniorApplied;

        uint256 seniorApplied = 0;
        if (remainingLoss > 0) {
            Market storage s = seniorMarkets[token];
            seniorApplied = _applyLossToMarket(s, remainingLoss);
            remainingLoss -= seniorApplied;
        }

        ln.defaulted = true;
        ln.liquidated = true;

        emit LoanDefaulted(unionAddr, loanId, juniorApplied, seniorApplied);
    }

    function transferLoan(
        address unionAddr,
        bytes32 loanId,
        address newBorrower,      // = address(0) or same as old → rollover only
        uint16  newRateBP,
        uint40  newMaturityTs,
        bytes   calldata newParams
        ) external whenNotPaused onlyOracleOrLeader(unionAddr) {
        Loan storage ln = unions[unionAddr].loans[loanId];
        if (ln.drawdownTs == 0) revert LoanNotExist();
        if (ln.defaulted || ln.liquidated) revert LoanClosed();

        // ---- settle window to 'now' with 3d tolerance on shortfall ----
        uint40 endTs = uint40(block.timestamp);
        uint256 elapsed  = uint256(endTs - ln.drawdownTs);
        uint256 accrued  = (uint256(ln.principal) * ln.rateBP * elapsed) / (10_000 * YEAR);

        if (ln.interestPaid < accrued) {
            uint256 shortfall = accrued - ln.interestPaid;
            uint256 tol = (uint256(ln.principal) * ln.rateBP * CARRYOVER_WINDOW) / (10_000 * YEAR);
            if (shortfall > tol) revert InterestNotSettled();
            // carry over: mark all interest to now as accounted
            ln.interestPaid = uint128(accrued);
        } else {
            // fully settled: reset accrual window
            ln.interestPaid = 0;
        }

        // ---- apply new terms ----
        ln.rateBP     = newRateBP;
        ln.drawdownTs = endTs;
        ln.maturityTs = newMaturityTs;

        // ---- optional reassignment (TRANSFER LOAN) ----
        address oldBorrower = ln.borrower;
        bool borrowerChanged = (newBorrower != address(0)) && (newBorrower != oldBorrower);
        if (borrowerChanged) {
            ln.borrower = newBorrower;                    // update current owner
            loansByBorrower[newBorrower].push(loanId);    // keep historical record
        }

        // ---- events ----
        if (borrowerChanged) {
            emit LoanTransferred(unionAddr, loanId, newBorrower, newRateBP, ln.drawdownTs);
        } else {
            emit LoanRolledOver(unionAddr, loanId, newRateBP, ln.drawdownTs);
        }
        if (newParams.length > 0) emit LoanParams(loanId, newParams);
    }

    //  ----------- ////////////////////// -----------
    //  -----------  VIEWERS RETURN DATA   -----------
    //  ----------- ////////////////////// -----------

    function getJuniorMarketLite(address unionAddr, address token, bytes32 loanType)
        external view returns (MarketLite memory)
            {
        Market storage m = unions[unionAddr].juniorByType[token][loanType];
        return MarketLite({
            supplyIndex:  m.supplyIndex,
            totalShares:  m.totalShares,
            totalBorrows: m.totalBorrows,
            maxDeposited: m.maxDeposited
        });
    }

    function getSeniorMarketLite(address token) 
        external view returns (MarketLite memory) 
            {
        Market storage s = seniorMarkets[token];
        return MarketLite({
            supplyIndex:  s.supplyIndex,
            totalShares:  s.totalShares,
            totalBorrows: 0,              // senior has no per-type borrows bucket
            maxDeposited: s.maxDeposited
        });
    }

    function getUnionCapBasePublic(address unionAddr, address token) external view returns (uint256) {
        return unionCapBase[unionAddr][token];
    }

    function investorLite(
        Tranche tranche,
        address unionAddr,
        address token,
        bytes32 loanType,
        address investor
        )
            external
            view
            returns (uint256 shares, uint256 entryIndex, uint256 unclaimed, uint256 lockedShares)
        {
            if (tranche == Tranche.JUNIOR) {
                InvestorInfo storage I = unions[unionAddr].investorsByType[token][loanType][investor];
                return (uint256(I.shares), uint256(I.entryIndex), uint256(I.unclaimed), uint256(I.lockedShares));
            } else {
                InvestorInfo storage S = seniorInvestors[token][investor];
                return (uint256(S.shares), uint256(S.entryIndex), uint256(S.unclaimed), uint256(S.lockedShares));
            }
    }

    function getLiquidityBufferState(address token)
        external view
        returns (
            uint16 safetyBP,
            uint256 safetyFloor,
            uint256 claimable,
            uint256 totalPending,
            uint256 hardStop,
            uint256 queueHead,
            uint256 queueLen
        )
        {
        safetyBP   = bufferSafetyBP[token];
        safetyFloor= bufferSafetyFloor[token];
        claimable  = pendingPrincipalClaimable[token];
        totalPending = pendingPrincipalTotal[token];
        hardStop   = hardStopClaimable[token];
        queueHead  = withdrawQueueHead[token];
        queueLen   = withdrawQueueByToken[token].length;
    }

    function getLoan(address unionAddr, bytes32 loanId) external view returns (Loan memory ln) {
        ln = unions[unionAddr].loans[loanId];
    }

    function getWithdrawRequestLite(uint256 id)
        external
        view
        returns (
            Tranche tranche,
            address investor,
            address unionAddr,
            address token,
            bytes32 loanType,
            uint256 shares,
            uint40 requestedAt,
            bool claimed,
            bool inKind1155
        )
        {
        WithdrawRequest storage R = withdrawRequests[id];
        return (R.tranche, R.investor, R.unionAddr, R.token, R.loanType, R.shares, R.requestedAt, R.claimed, R.inKind1155);
    }


    function getLoansByBorrower(
        address borrower
        ) external view returns (bytes32[] memory) {
        return loansByBorrower[borrower];
    }

    function isOracleSigner(address signer) external view returns (bool) {
        return oracleSigners[signer];
    }

    // ───────── storage gap ─────────
    uint256[20] private __gap;
}
