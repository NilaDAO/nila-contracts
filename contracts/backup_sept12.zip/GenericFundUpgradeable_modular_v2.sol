// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
 * GenericFundUpgradeable — Core (v1.3)
 * Tasks:
 * 
 * INVEST
 * deposit ERC20: Junior and Senior
 * deposit ERC1155: Junior 
 * withdraw pending interest Junior and Senior
 * withdraw 
 * 
 * 
 * 
 * What lives here (Core):
 * - State (unions, markets, investors, loans)
 * - Loan lifecycle: fund → claim → repay → default/liquidate → transfer/rollover
 * - ERC20 Senior/Junior deposits & unbonding (ERC-20 only)
 * - Liquidity buffer check before funding loans
 * - Interest distribution (1% treasury, 50/50 Jr/Sr for matching token & loanType)
 * - Index accounting (per-tranche share index) using GenericFundMathLib.RAY
 *
 * What does NOT live here:
 * - Read-only list/preview helpers → moved to Viewer
 * - ERC-1155 flows & oracle quoting → moved to 1155 Module
 * - Duplicate RAY constants/math → centralized in GenericFundMathLib
 */

import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";

//  ----------- Custom math libary -----------
import "./GenericFundMathLib.sol";

interface IPriceOracleLike {
    function isLeader(address unionAddr, address account) external view returns (bool);
    function isOracle(address account) external view returns (bool);
}

interface IERC721Like {
    function balanceOf(address owner) external view returns (uint256);
}

/// @notice Minimal viewer-facing types (mirrored by Viewer)
library IFundCore {
    enum Tranche { JUNIOR, SENIOR }

    struct InvestorLite {
        uint256 shares;
        uint256 locked;     // shares locked for withdraw (pending + claimable)
        uint256 pending;    // shares pending promotion to claimable
    }

    struct MarketLite {
        uint256 cash;       // idle liquidity (token units)
        uint256 index;      // RAY share index
        uint256 totalShares;
        uint256 totalBorrows;
        uint256 claimablePrincipal; // principal reserved for matured unbonds (token units)
    }

    struct Loan {
        address token;
        address borrower;
        bytes32 loanType;
        uint128 principal;
        uint16  rateBP;        // annualized basis points
        uint40  createTs;
        uint40  drawdownTs;    // zero until claimed
        uint40  maturityTs;
        uint128 principalPaid; // cumulative principal paid
        uint128 interestPaid;  // cumulative interest paid
        bool    defaulted;
        bool    liquidated;
    }
}

contract GenericFundUpgradeable_V2 is
    Initializable,
    OwnableUpgradeable,
    PausableUpgradeable,
    UUPSUpgradeable,
    ReentrancyGuardUpgradeable
{
    using GenericFundMathLib for uint256;

    // ---------- Config ----------
    uint256 public constant YEAR = 365 days;
    uint256 public constant HUNDRED_PERCENT_BP = 10_000;
    uint256 public constant TREASURY_FEE_BP = 100; // 1%
    uint256 public constant DEFAULT_UNBONDING = 14 days;
    uint256 private constant PAYBACK_PERIOD = 6 weeks; // 42 days
    uint256 public constant CARRYOVER_WINDOW = 3 days; // tolerance for unpaid interest on transfer

    address public treasury;            // receives 1% of interest
    IPriceOracleLike public roles;      // oracle/leaders registry

    // ── Per-union+token liquidity buffer config ───────────────────────────────────
    struct ReserveCfg {
        uint32  safetyBP;     // bps on top of claimables
        uint224 safetyFloor;  // flat floor in token units
        bool    hardStop;     // strict stop if below required
        bool    exists;       // must be set before usage
    }
    // union => token => cfg
    mapping(address => mapping(address => ReserveCfg)) public reserveCfgByUnionToken;

    // Aggregated claimable principal per {union, token} (ERC20 juniors + seniors via sentinel)
    mapping(address => mapping(address => uint256)) public unionClaimableByToken; 

    // Borrow caps (per union, per token), and historical maxima (per junior market)
    mapping(address => mapping(address => uint256)) public seniorCap; // union => token => cap
    // Sum of per-type historical maxDeposited is maintained per union+token
    mapping(address => mapping(address => uint256)) public juniorMaxSum; // union => token => sum(maxDeposited over all loanTypes)

    // ──────────────────────────────────────────────
    // Union registry + Fund Types (≤ 15 per union)
    // ──────────────────────────────────────────────
    struct Union {
        string name;
        bool   active;

        // Allowed fund types (loanType = bytes32, but you can pass keccak256 of the string)
        mapping(bytes32 => bool) isFundType;
        mapping(bytes32 => string) fundTypeName; // optional friendly name
        bytes32[] fundTypes;                     // enumerable list
    }
    mapping(address => Union) internal unions;

    // ---------- Tranche markets ----------
    // Senior is global per token
    struct SeniorMarket {
        uint256 cash;
        uint256 index;        // RAY
        uint256 totalShares;
        uint256 totalBorrows;     
        uint256 claimablePrincipal; // reserved principal for matured unbonds (from ERC20 side)
    }
    mapping(address => SeniorMarket) internal senior; // token => market
    
    // Junior is per {union, token, loanType}
    struct JuniorMarket {
        uint256 cash;
        uint256 index;        // RAY
        uint256 totalShares;
        uint256 claimablePrincipal;
        uint256 historicalMaxDeposited;
        uint256 totalBorrows;       
        bool exists;
    }
    // union => token => loanType => market
    mapping(address => mapping(address => mapping(bytes32 => JuniorMarket))) internal junior;
    // ───────── Rate model per {union, token} ─────────
    mapping(address => mapping(address => GenericFundMathLib.RateParams)) public rateParamsByUnionToken;
    // Aggregate borrows for utilization per {union, token}
    mapping(address => mapping(address => uint256)) internal unionBorrowsAgg;

    // ---------- Investors (ERC20 side only; 1155 lives in module) ----------
    // Senior investors: token => investor => state
    struct Investor {
        uint256 shares;
        uint256 pending;    // shares requested to unbond (awaiting promotion)
        uint256 claimable;  // shares promoted and ready to claim (accrues until claim)
        uint40  requestTs;  // last unbond request timestamp
        uint256 entryIndex;   // last settled index (RAY)
        uint256 unclaimed;    // settled yield awaiting payout (token units)
        uint256 pendingPrincipalSnap; // sum of principal snapshots reserved at request time
    }
    mapping(address => mapping(address => Investor)) internal seniorInv; // token => addr => inv

    // Junior investors: union => token => loanType => investor => state
    mapping(address => mapping(address => mapping(bytes32 => mapping(address => Investor)))) internal juniorInv;

    // ---------- Loans ----------
    // union => loanId => loan
    mapping(address => mapping(bytes32 => IFundCore.Loan)) public loans;

    // ---------- Token-level accounting that the 1155 module may update ----------
    // To support reserve checks that include ERC1155 flows, the module calls hooks to bump these.
    mapping(address => uint256) public moduleCashByToken;           // net cash adjusted by module

    // ── Maturity ledger per {union, token} ───────────────────────────────────────
    mapping(address => mapping(address => mapping(uint40 => uint256))) internal scheduledPrincipalByDate; // union => token => maturityTs => amount
    mapping(address => mapping(address => uint256)) internal maturedCreditByUnionToken;   // matured principal credited (not yet consumed by promotions)
    mapping(address => mapping(address => uint256)) internal maturedConsumedByUnionToken; // consumed by promotions

    // ---------- Set land title address ----------
    mapping(address => address) public unionLandNFT; // union => ERC721 collection
    
    // Track per-loan scheduled remainder (lets us adjust on early principal repayments/default)
    mapping(address => mapping(bytes32 => uint256)) internal loanScheduledPrincipal; // union => loanId => remaining scheduled principal

    // ---------- Events ----------
    event Initialized(address treasury, address roles);
    event ReserveUpdated(address indexed token, uint32 safetyBP, uint224 safetyFloor, bool hardStop);
    event SeniorCapUpdated(address indexed unionAddr, address indexed token, uint256 cap);
    event JuniorMarketCreated(address indexed unionAddr, address indexed token, bytes32 indexed loanType);

    // ---------- Union settings ----------
    event UnionActivated(address indexed unionAddr, string name);
    event UnionDeactivated(address indexed unionAddr);
    event UnionReserveUpdated(address indexed unionAddr, address indexed token, uint32 safetyBP, uint224 safetyFloor, bool hardStop);
    event UnionLandNFTSet(address indexed unionAddr, address indexed collection);
    event FundTypeAdded(address indexed unionAddr, bytes32 indexed loanType, string name);
    event FundTypeRemoved(address indexed unionAddr, bytes32 indexed loanType);
    event RateParamsUpdated( address indexed unionAddr, address indexed token,uint16 baseRateBP, uint16 kinkUtilBP, uint16 slope1BP,uint16 slope2BP,uint16 maxRateBP );
    event Deposit(address indexed investor, IFundCore.Tranche tranche, address indexed unionAddr, address indexed token, bytes32 loanType, uint256 amount, uint256 sharesOut);
    event UnbondRequested(address indexed investor, IFundCore.Tranche tranche, address indexed unionAddr, address indexed token, bytes32 loanType, uint256 shares, uint256 principalSnap);
    event UnbondPromoted(address indexed investor, IFundCore.Tranche tranche, address indexed unionAddr, address indexed token, bytes32 loanType, uint256 shares, uint256 principalSnap);
    event Claimed(address indexed investor, IFundCore.Tranche tranche, address indexed unionAddr, address indexed token, bytes32 loanType, uint256 amount);
    event YieldClaimed(address indexed investor, IFundCore.Tranche tranche, address indexed unionAddr, address indexed token, bytes32 loanType, uint256 amount);

    event LoanFunded(address indexed unionAddr, bytes32 indexed loanId, address indexed token, address borrower, bytes32 loanType, uint256 amount, uint16 rateBP, uint40 maturityTs);
    event LoanClaimed(address indexed unionAddr, bytes32 indexed loanId, address borrower, uint256 amount);
    event LoanRepaid(address indexed unionAddr, bytes32 indexed loanId, uint256 interestPaid, uint256 principalPaid);
    event LoanTransferred(address indexed unionAddr, bytes32 indexed loanId, address oldBorrower, address newBorrower, uint16 newRateBP, uint40 newMaturityTs);
    event LoanDefaulted(address indexed unionAddr, bytes32 indexed loanId, uint256 juniorApplied, uint256 seniorApplied);
    event RecoveryCredited(address indexed unionAddr, bytes32 indexed loanId, uint256 recovered);
    event MaturityReported(address indexed unionAddr, bytes32 indexed loanId, uint40 maturityTs);
    event MaturitiesCredited(address indexed unionAddr, address indexed token, uint40 date, uint256 amount);

    // ---------- Modifiers ----------
    modifier onlyOracleOrLeader(address unionAddr) {
        require(
            (address(roles) != address(0) && (roles.isOracle(msg.sender) || roles.isLeader(unionAddr, msg.sender))) ||
            owner() == msg.sender,
            "not oracle/leader"
        );
        _;
    }

    // ---------- Initializer / Upgrader ----------
    function initialize(address _treasury, address _roles) external initializer {
        __Ownable_init(msg.sender);
        __Pausable_init();
        __UUPSUpgradeable_init();
        __ReentrancyGuard_init();

        require(_treasury != address(0), "treasury=0");
        treasury = _treasury;
        roles = IPriceOracleLike(_roles);

        emit Initialized(_treasury, _roles);
    }

    function _authorizeUpgrade(address newImpl) internal override onlyOwner {}

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    // ---------- Admin ----------
    function setReserveConfigForUnionToken(
        address unionAddr,
        address token,
        uint32 safetyBP,
        uint224 safetyFloor,
        bool hardStop
        ) external onlyOracleOrLeader(unionAddr) {
        reserveCfgByUnionToken[unionAddr][token] = ReserveCfg({
            safetyBP: safetyBP,
            safetyFloor: safetyFloor,
            hardStop: hardStop,
            exists: true
        });
        emit UnionReserveUpdated(unionAddr, token, safetyBP, safetyFloor, hardStop);
    }

    function setSeniorCap(address unionAddr, address token, uint256 cap) external onlyOwner {
        seniorCap[unionAddr][token] = cap;
        emit SeniorCapUpdated(unionAddr, token, cap);
    }

    function setUnionLandNFT(address unionAddr, address collection) external onlyOracleOrLeader(unionAddr) {
        require(unions[unionAddr].active, "union inactive");
        unionLandNFT[unionAddr] = collection; // collection can be address(0) to disable
        emit UnionLandNFTSet(unionAddr, collection);
    }

    // ---------- Internal helpers ----------
    function _ensureJuniorMarket(address unionAddr, address token, bytes32 loanType) internal {
        JuniorMarket storage m = junior[unionAddr][token][loanType];
        if (!m.exists) {
            m.exists = true;
            m.index = GenericFundMathLib.RAY; // 1.0
            emit JuniorMarketCreated(unionAddr, token, loanType);
        }
    }

    function _ensureSeniorMarket(address token) internal {
        SeniorMarket storage m = senior[token];
        if (m.index == 0) {
            m.index = GenericFundMathLib.RAY; // 1.0
        }
    }

    function _distributeInterest(address unionAddr, address token, bytes32 loanType, uint256 interest) internal {
        // 1% fee to treasury
        uint256 fee = (interest * TREASURY_FEE_BP) / HUNDRED_PERCENT_BP;
        if (fee > 0) {
            IERC20(token).transfer(treasury, fee);
        }
        uint256 net = interest - fee;

        // split 50/50 to junior (matching loanType) and senior (global per token)
        uint256 toJunior = net / 2;
        uint256 toSenior = net - toJunior;

        // Add cash
        junior[unionAddr][token][loanType].cash += toJunior;
        senior[token].cash += toSenior;

        // Increase indexes: deltaIndex = interest * RAY / totalShares
        if (junior[unionAddr][token][loanType].totalShares > 0) {
            uint256 dIdxJ = (toJunior * GenericFundMathLib.RAY) / junior[unionAddr][token][loanType].totalShares;
            junior[unionAddr][token][loanType].index += dIdxJ;
        }
        if (senior[token].totalShares > 0) {
            uint256 dIdxS = (toSenior * GenericFundMathLib.RAY) / senior[token].totalShares;
            senior[token].index += dIdxS;
        }
    }

    function _settleYieldSenior(address token, address investor) internal {
        Investor storage inv = seniorInv[token][investor];
        uint256 idx = senior[token].index == 0 ? GenericFundMathLib.RAY : senior[token].index;
        if (inv.entryIndex == 0) { inv.entryIndex = idx; return; }
        if (idx > inv.entryIndex && inv.shares > 0) {
            uint256 delta = idx - inv.entryIndex;
            inv.unclaimed += (inv.shares * delta) / GenericFundMathLib.RAY;
            inv.entryIndex = idx;
        } else {
            inv.entryIndex = idx; // keep synced
        }
    }

    function _settleYieldJunior(address unionAddr, address token, bytes32 loanType, address investor) internal {
        Investor storage inv = juniorInv[unionAddr][token][loanType][investor];
        uint256 idx = junior[unionAddr][token][loanType].index == 0 ? GenericFundMathLib.RAY : junior[unionAddr][token][loanType].index;
        if (inv.entryIndex == 0) { inv.entryIndex = idx; return; }
        if (idx > inv.entryIndex && inv.shares > 0) {
            uint256 delta = idx - inv.entryIndex;
            inv.unclaimed += (inv.shares * delta) / GenericFundMathLib.RAY;
            inv.entryIndex = idx;
        } else {
            inv.entryIndex = idx;
        }
    }

    function _computeHaircut(
        uint256 supplyIndex,      // RAY
        uint256 totalShares,
        uint256 loss
        ) internal pure returns (uint256 applied, uint256 newIndex) {
        if (loss == 0 || supplyIndex == 0 || totalShares == 0) return (0, supplyIndex);
        uint256 underlying = GenericFundMathLib.toUnderlying(totalShares, supplyIndex);
        if (underlying == 0) return (0, supplyIndex);
        (applied, newIndex) = GenericFundMathLib.haircutIndex(supplyIndex, underlying, loss);
    }
    
    function _applyLossJunior(JuniorMarket storage jm, uint256 loss) internal returns (uint256 applied) {
        uint256 newIdx;
        (applied, newIdx) = _computeHaircut(uint256(jm.index), jm.totalShares, loss);
        jm.index = uint128(newIdx);
    }

    function _applyLossSenior(SeniorMarket storage sm, uint256 loss) internal returns (uint256 applied) {
        uint256 newIdx;
        (applied, newIdx) = _computeHaircut(uint256(sm.index), sm.totalShares, loss);
        sm.index = uint128(newIdx);
    }

    function _requireHoldsNFT(address collection, address holder) internal view {
        if (collection == address(0)) return; // gating disabled
        require(IERC721Like(collection).balanceOf(holder) > 0, "NFT required");
    }

    function _requireNotHoldingNFT(address collection, address holder) internal view {
        if (collection == address(0)) return; // gating disabled
        require(IERC721Like(collection).balanceOf(holder) == 0, "NFT must NOT hold");
    }

    function _bumpUnionClaimable(address unionAddr, address token, int256 principalDelta) internal {
        if (principalDelta > 0) {
            unionClaimableByToken[unionAddr][token] += uint256(principalDelta);
        } else if (principalDelta < 0) {
            unionClaimableByToken[unionAddr][token] -= uint256(-principalDelta);
        }
    }

    // Required reserve for a specific {union, token}
    function _requiredReserveFor(address unionAddr, address token)
        internal
        view
        returns (ReserveCfg memory cfg, uint256 req)
        {
        cfg = reserveCfgByUnionToken[unionAddr][token];
        require(cfg.exists, "reserve cfg !set");
        uint256 claimable = unionClaimableByToken[unionAddr][token];
        uint256 bump = (uint256(cfg.safetyBP) * claimable) / HUNDRED_PERCENT_BP;
        req = claimable + bump + uint256(cfg.safetyFloor);
    }

    // Enforce reserve for funding a loan in {union, token}
    function _checkReserveBeforeFundingFor(
        address unionAddr,
        address token,
        bytes32 loanType,
        uint256 amount
        ) internal view {
        (, uint256 req) = _requiredReserveFor(unionAddr, token);
        uint256 idle = junior[unionAddr][token][loanType].cash + senior[token].cash + moduleCashByToken[token];
        require(idle >= amount + req, "insufficient reserve");
    }

    // ---------- Module hooks (called by ERC1155 module) ----------
    function onModuleCashDelta(address token, int256 delta) external {
        // trust-caller: set your 1155 module as an allowed caller via roles or owner (simplified here)
        require(roles.isOracle(msg.sender) || msg.sender == owner(), "module !auth");
        if (delta > 0) {
            moduleCashByToken[token] += uint256(delta);
        } else if (delta < 0) {
            moduleCashByToken[token] -= uint256(-delta);
        }
    }

    // ---------- UNION SETTINGS ---------------
    function activateUnion(address unionAddr, string calldata name) external onlyOwner {
        require(unionAddr != address(0), "union=0");
        Union storage u = unions[unionAddr];
        u.active = true;
        u.name = name;
        emit UnionActivated(unionAddr, name);
    }

    /// @notice Owner deactivates a union (no automatic fund return here).
    function deactivateUnion(address unionAddr) external onlyOwner {
        Union storage u = unions[unionAddr];
        require(u.active, "not active");
        u.active = false;
        emit UnionDeactivated(unionAddr);
    }

    function setRateParams(
        address unionAddr,
        address token,
        uint16 baseRateBP,
        uint16 kinkUtilBP, // 0..10000
        uint16 slope1BP,
        uint16 slope2BP,
        uint16 maxRateBP
        ) external onlyOracleOrLeader(unionAddr) {
        require(kinkUtilBP > 0 && kinkUtilBP <= 10_000, "bad kink");
        require(maxRateBP >= baseRateBP, "max<base");
        rateParamsByUnionToken[unionAddr][token] = GenericFundMathLib.RateParams({
            baseRateBP:  baseRateBP,
            kinkUtilBP:  kinkUtilBP,
            slope1BP:    slope1BP,
            slope2BP:    slope2BP,
            maxRateBP:   maxRateBP
        });
        emit RateParamsUpdated(unionAddr, token, baseRateBP, kinkUtilBP, slope1BP, slope2BP, maxRateBP);
    }

    /// @notice Leader/Oracle adds a fund type (<= 15) for a union.
    function addFundType(address unionAddr, bytes32 loanType, string calldata displayName)
        external
        onlyOracleOrLeader(unionAddr)
        {
        Union storage u = unions[unionAddr];
        require(u.active, "union inactive");
        require(loanType != bytes32(0), "loanType=0");
        require(!u.isFundType[loanType], "exists");
        require(u.fundTypes.length < 15, "too many fund types");

        u.isFundType[loanType] = true;
        u.fundTypeName[loanType] = displayName;
        u.fundTypes.push(loanType);

        emit FundTypeAdded(unionAddr, loanType, displayName);
    }

    /// @notice Leader/Oracle removes a fund type (blocks new usage; existing markets untouched).
    function removeFundType(address unionAddr, bytes32 loanType)
        external
        onlyOracleOrLeader(unionAddr)
        {
        Union storage u = unions[unionAddr];
        require(u.isFundType[loanType], "not exists");
        u.isFundType[loanType] = false;
        delete u.fundTypeName[loanType];

        // remove from array (swap & pop)
        for (uint256 i = 0; i < u.fundTypes.length; i++) {
            if (u.fundTypes[i] == loanType) {
                u.fundTypes[i] = u.fundTypes[u.fundTypes.length - 1];
                u.fundTypes.pop();
                break;
            }
        }
        emit FundTypeRemoved(unionAddr, loanType);
    }

    // ---------- ERC20 Senior ----------
    function depositSenior(address token, uint256 amount) external whenNotPaused nonReentrant {
        require(amount > 0, "amount=0");
        _ensureSeniorMarket(token);
        _settleYieldSenior(token, msg.sender); // NEW

        IERC20(token).transferFrom(msg.sender, address(this), amount);

        SeniorMarket storage m = senior[token];
        m.cash += amount;

        uint256 pps = m.index == 0 ? GenericFundMathLib.RAY : m.index;
        uint256 shares = (amount * GenericFundMathLib.RAY) / pps; // ← no mulRay/divRay
        m.totalShares += shares;
        seniorInv[token][msg.sender].shares += shares;

        emit Deposit(msg.sender, IFundCore.Tranche.SENIOR, address(0), token, bytes32(0), amount, shares);
    }

    function requestUnbondSenior(address token, uint256 shares) external whenNotPaused {
        Investor storage inv = seniorInv[token][msg.sender];
        require(shares > 0 && shares <= inv.shares - inv.pending - inv.claimable, "bad shares");

        inv.pending += shares;
        inv.requestTs = uint40(block.timestamp);

        // snapshot principal reserved for this request (for reserve accounting)
        uint256 amountSnap = shares * senior[token].index; // token units        

        senior[token].claimablePrincipal += amountSnap;
        // NEW: also reflect in union-level (sentinel union = address(0))
        _bumpUnionClaimable(address(0), token, int256(amountSnap));

        emit UnbondRequested(msg.sender, IFundCore.Tranche.SENIOR, address(0), token, bytes32(0), shares, amountSnap);
    }

    function claimSenior(address token, uint256 maxShares) external nonReentrant {
        _settleYieldSenior(token, msg.sender); // NEW

        Investor storage inv = seniorInv[token][msg.sender];
        require(inv.claimable > 0, "nothing to claim");

        if (inv.claimable == 0 && inv.pending > 0) {
            require(block.timestamp >= inv.requestTs + DEFAULT_UNBONDING, "wait unbonding window");
            inv.claimable += inv.pending;
            inv.pending = 0;
        }

        uint256 shares = maxShares == 0 ? inv.claimable : (maxShares <= inv.claimable ? maxShares : inv.claimable);
        uint256 amount = shares * senior[token].index;

        (ReserveCfg memory cfg, uint256 req) = _requiredReserveFor(address(0), token);
        uint256 idle = senior[token].cash + moduleCashByToken[token];
        if (cfg.hardStop) require(idle >= amount + req, "reserve stop");
        require(senior[token].cash >= amount, "cash < claim");

        inv.claimable -= shares;
        inv.shares    -= shares;               // NEW: keep investor.shares accurate
        senior[token].totalShares -= shares;
        senior[token].cash        -= amount;

        uint256 principalRelease = amount;
        if (principalRelease > senior[token].claimablePrincipal) principalRelease = senior[token].claimablePrincipal;
        senior[token].claimablePrincipal -= principalRelease;
        _bumpUnionClaimable(address(0), token, -int256(principalRelease));

        IERC20(token).transfer(msg.sender, amount);
        emit Claimed(msg.sender, IFundCore.Tranche.SENIOR, address(0), token, bytes32(0), amount);
    }

    // ---------- ERC20 Junior ----------
    function depositJunior(address unionAddr, address token, bytes32 loanType, uint256 amount) external whenNotPaused nonReentrant {
        require(amount > 0, "amount=0");
        Union storage u = unions[unionAddr];
        require(u.active, "union inactive");
        require(u.isFundType[loanType], "fundType !allowed");

        _requireHoldsNFT(unionLandNFT[unionAddr], msg.sender);
        _ensureJuniorMarket(unionAddr, token, loanType);
        _settleYieldJunior(unionAddr, token, loanType, msg.sender); // NEW
        IERC20(token).transferFrom(msg.sender, address(this), amount);

        JuniorMarket storage m = junior[unionAddr][token][loanType];
        m.cash += amount;

        uint256 pps = m.index;
        uint256 shares = (amount * GenericFundMathLib.RAY) / pps; // ← no mulRay/divRay
        m.totalShares += shares;

        Investor storage inv = juniorInv[unionAddr][token][loanType][msg.sender];
        inv.shares += shares;

        // track historical max
        uint256 depositedNow = shares * pps;
        if (depositedNow > m.historicalMaxDeposited) {
            juniorMaxSum[unionAddr][token] = juniorMaxSum[unionAddr][token] - m.historicalMaxDeposited + depositedNow;
            m.historicalMaxDeposited = depositedNow;
        }

        emit Deposit(msg.sender, IFundCore.Tranche.JUNIOR, unionAddr, token, loanType, amount, shares);
    }

    function requestUnbondJunior(address unionAddr, address token, bytes32 loanType, uint256 shares) external whenNotPaused {
        _ensureJuniorMarket(unionAddr, token, loanType);
        Investor storage inv = juniorInv[unionAddr][token][loanType][msg.sender];
       
        require(shares > 0 && shares <= inv.shares - inv.pending - inv.claimable, "bad shares");

        inv.pending += shares;
        inv.requestTs = uint40(block.timestamp);

        // snapshot principal reserved for this request (reserve accounting)
        uint256 amountSnap = shares * junior[unionAddr][token][loanType].index;
        inv.pendingPrincipalSnap += amountSnap; // NEW: remember FIFO principal snapshot
        junior[unionAddr][token][loanType].claimablePrincipal += amountSnap;
        _bumpUnionClaimable(unionAddr, token, int256(amountSnap));

        emit UnbondRequested(msg.sender, IFundCore.Tranche.JUNIOR, unionAddr, token, loanType, shares, amountSnap);
    }

    function claimJunior(
        address unionAddr,
        address token,
        bytes32 loanType,
        uint256 maxShares
        ) external nonReentrant {
        _ensureJuniorMarket(unionAddr, token, loanType);

        Investor storage inv = juniorInv[unionAddr][token][loanType][msg.sender];


        // ── eligibility gate & auto-promotion ─────────────────────────────────────
        if (inv.claimable == 0 && inv.pending > 0) {
            bool pastMin = block.timestamp >= inv.requestTs + DEFAULT_UNBONDING;

            // maturity-aware early coverage budget for this {union, token}
            uint256 availableBudget = maturedCreditByUnionToken[unionAddr][token]
                - maturedConsumedByUnionToken[unionAddr][token];

            bool covered = (inv.pendingPrincipalSnap > 0 && availableBudget >= inv.pendingPrincipalSnap);

            // require BOTH: "later of" rule
            require(pastMin && covered, "not eligible: wait window or maturities");

            // auto-promote pending -> claimable and consume budget
            uint256 toPromote = inv.pending;
            inv.pending = 0;
            inv.claimable += toPromote;
            maturedConsumedByUnionToken[unionAddr][token] += inv.pendingPrincipalSnap;
            inv.pendingPrincipalSnap = 0;

            // optional: signal promotion for offchain UIs
            emit UnbondPromoted(msg.sender, IFundCore.Tranche.JUNIOR, unionAddr, token, loanType, toPromote, 0);
        }

        require(inv.claimable > 0, "nothing to claim");

        // ── compute amount to pay (principal redemption) ──────────────────────────
        JuniorMarket storage m = junior[unionAddr][token][loanType];

        uint256 shares = (maxShares == 0 || maxShares > inv.claimable) ? inv.claimable : maxShares;
        uint256 amount = shares * m.index; // token units

        // ── liquidity & buffer check ──────────────────────────────────────────────
        (ReserveCfg memory cfg, uint256 req) = _requiredReserveFor(unionAddr, token);
        uint256 idle = junior[unionAddr][token][loanType].cash + senior[token].cash + moduleCashByToken[token];
        if (cfg.hardStop) require(idle >= amount + req, "reserve stop");

        require(m.cash >= amount, "cash < claim");

        // ── burn shares & move cash ───────────────────────────────────────────────
        inv.claimable -= shares;
        inv.shares    -= shares;            // keep investor shares correct
        m.totalShares -= shares;
        m.cash        -= amount;

        // release reserved principal (both token-level + union-level aggregators)
        uint256 principalRelease = amount;
        if (principalRelease > m.claimablePrincipal) principalRelease = m.claimablePrincipal;
        m.claimablePrincipal -= principalRelease;
        
        _bumpUnionClaimable(unionAddr, token, -int256(principalRelease));

        IERC20(token).transfer(msg.sender, amount);
        emit Claimed(msg.sender, IFundCore.Tranche.JUNIOR, unionAddr, token, loanType, amount);
    }

    function claimYield(
        IFundCore.Tranche tranche,
        address unionAddr,   // use address(0) for senior
        address token,
        bytes32 loanType,    // ignored for senior
        uint256 maxAmount    // 0 = claim all available
        ) external nonReentrant whenNotPaused {
        uint256 available;
        uint256 payableAmt;
        uint256 idle;
        ReserveCfg memory cfg;
        uint256 req;

        if (tranche == IFundCore.Tranche.SENIOR) {
            // ── settle & load state ───────────────────────────────────────────────
            _ensureSeniorMarket(token);
            _settleYieldSenior(token, msg.sender);

            Investor storage inv = seniorInv[token][msg.sender];
            available = inv.unclaimed;
            require(available > 0, "no yield");

            // ── union-aware reserve: sentinel union = address(0) for senior ───────
            (cfg, req) = _requiredReserveFor(address(0), token);
            idle = senior[token].cash + moduleCashByToken[token];

            // ── headroom & payout ─────────────────────────────────────────────────
            payableAmt = (maxAmount == 0 || maxAmount > available) ? available : maxAmount;
            uint256 headroom = idle > req ? (idle - req) : 0;
            if (cfg.hardStop) {
                require(idle >= req + payableAmt, "reserve stop");
            } else if (payableAmt > headroom) {
                payableAmt = headroom;
            }
            require(payableAmt > 0 && payableAmt <= senior[token].cash, "no cash");

            // ── transfer ─────────────────────────────────────────────────────────
            inv.unclaimed -= payableAmt;
            senior[token].cash -= payableAmt;
            IERC20(token).transfer(msg.sender, payableAmt);
            emit YieldClaimed(msg.sender, IFundCore.Tranche.SENIOR, address(0), token, bytes32(0), payableAmt);

        } else {
            // ── settle & load state ───────────────────────────────────────────────
            _ensureJuniorMarket(unionAddr, token, loanType);
            _settleYieldJunior(unionAddr, token, loanType, msg.sender);

            Investor storage invJ = juniorInv[unionAddr][token][loanType][msg.sender];
            available = invJ.unclaimed;
            require(available > 0, "no yield");

            // ── union-aware reserve ───────────────────────────────────────────────
            (cfg, req) = _requiredReserveFor(unionAddr, token);
            idle = junior[unionAddr][token][loanType].cash + senior[token].cash + moduleCashByToken[token];

            // ── headroom & payout ─────────────────────────────────────────────────
            payableAmt = (maxAmount == 0 || maxAmount > available) ? available : maxAmount;
            uint256 headroom = idle > req ? (idle - req) : 0;
            if (cfg.hardStop) {
                require(idle >= req + payableAmt, "reserve stop");
            } else if (payableAmt > headroom) {
                payableAmt = headroom;
            }
            require(payableAmt > 0 && payableAmt <= junior[unionAddr][token][loanType].cash, "no cash");

            // ── transfer ─────────────────────────────────────────────────────────
            invJ.unclaimed -= payableAmt;
            junior[unionAddr][token][loanType].cash -= payableAmt;
            IERC20(token).transfer(msg.sender, payableAmt);
            emit YieldClaimed(msg.sender, IFundCore.Tranche.JUNIOR, unionAddr, token, loanType, payableAmt);
        }
    }

    // ---------- Loan lifecycle ----------
    function fundLoan(
        address unionAddr,
        bytes32 loanId,
        address token,
        address borrower,
        bytes32 loanType,
        uint128 amount,
        uint16  rateBP,
        uint40  maturityTs
        ) external whenNotPaused onlyOracleOrLeader(unionAddr) {
        require(borrower != address(0), "borrower=0");
        require(amount > 0, "amount=0");
        // (if you added union registry + fund types)
        require(unions[unionAddr].active, "union inactive");
        require(unions[unionAddr].isFundType[loanType], "fundType !allowed");
        
        // --- CAP & MODEL (computed internally) ---
        uint256 borrows = unionBorrowsAgg[unionAddr][token];
        uint256 cap = 2 * (juniorMaxSum[unionAddr][token] + seniorCap[unionAddr][token]);
        require(cap > 0, "cap=0");
        require(borrows + amount <= cap, "cap exceeded");

        GenericFundMathLib.RateParams memory p = rateParamsByUnionToken[unionAddr][token];
        uint16 model = GenericFundMathLib.quoteRateBP(p, cap, borrows, amount);
        require(rateBP >= model, "rate < model");

        // --- check if borrower holds a land title ---
        _requireHoldsNFT(unionLandNFT[unionAddr], borrower);

        // --- Reserve check & waterfall (your existing logic) ---
        _checkReserveBeforeFundingFor(unionAddr, token, loanType, amount);

        uint256 takeJunior = amount <= junior[unionAddr][token][loanType].cash
            ? amount
            : junior[unionAddr][token][loanType].cash;
        junior[unionAddr][token][loanType].cash -= takeJunior;

        uint256 takeSenior = amount - takeJunior;
        if (takeSenior > 0) {
            require(senior[token].cash >= takeSenior, "senior cash");
            senior[token].cash -= takeSenior;
        }

        // --- Write loan (your fields) ---
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(ln.createTs == 0, "loan exists");
        ln.token      = token;
        ln.borrower   = borrower;
        ln.loanType   = loanType;
        ln.principal  = amount;
        ln.rateBP     = rateBP;
        ln.createTs   = uint40(block.timestamp);
        ln.maturityTs = maturityTs;

        // --- Utilization tracking for future previews ---
        unionBorrowsAgg[unionAddr][token] = borrows + amount;
        junior[unionAddr][token][loanType].totalBorrows += amount; // if you track this per-type

        emit LoanFunded(unionAddr, loanId, token, borrower, loanType, amount, rateBP, maturityTs);
    }

    function claimLoan(address unionAddr, bytes32 loanId) external nonReentrant whenNotPaused {
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(ln.createTs != 0 && ln.drawdownTs == 0, "bad state");
        require(!ln.defaulted && !ln.liquidated, "closed");
        require(msg.sender == ln.borrower, "not borrower");

        ln.drawdownTs = uint40(block.timestamp);
        IERC20(ln.token).transfer(ln.borrower, ln.principal);

        emit LoanClaimed(unionAddr, loanId, ln.borrower, ln.principal);
    }

    function repayLoan(address unionAddr, bytes32 loanId, uint256 amount) external nonReentrant whenNotPaused {
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(ln.drawdownTs != 0 && !ln.defaulted && !ln.liquidated, "bad state");
        require(amount > 0, "amount=0");

        IERC20(ln.token).transferFrom(msg.sender, address(this), amount);

        // compute accrued interest since drawdown (simple interest)
        uint256 elapsed = block.timestamp - uint256(ln.drawdownTs);
        uint256 accrued = (uint256(ln.principal) * ln.rateBP * elapsed) / (HUNDRED_PERCENT_BP * YEAR);
        uint256 interestOwed = accrued > ln.interestPaid ? (accrued - ln.interestPaid) : 0;

        uint256 payInterest = amount >= interestOwed ? interestOwed : amount;
        uint256 payPrincipal = amount - payInterest;
        
        if (payInterest > 0) {
            ln.interestPaid += uint128(payInterest);
            _distributeInterest(unionAddr, ln.token, ln.loanType, payInterest);
        }
        if (payPrincipal > 0) {
            // per-union utilization
            uint256 ub = unionBorrowsAgg[unionAddr][ln.token];
            unionBorrowsAgg[unionAddr][ln.token] = payPrincipal >= ub ? 0 : (ub - payPrincipal);

            // per-loanType counter
            JuniorMarket storage jm = junior[unionAddr][ln.token][ln.loanType];
            uint256 tb = jm.totalBorrows;
            jm.totalBorrows = payPrincipal >= tb ? 0 : (tb - payPrincipal);
            // record on the loan
            ln.principalPaid += uint128(payPrincipal);

            // if repaid BEFORE maturity, reduce the scheduled bucket
            if (ln.maturityTs != 0 && block.timestamp < uint256(ln.maturityTs)) {
                uint256 sched = loanScheduledPrincipal[unionAddr][loanId];
                if (sched > 0) {
                    uint256 cut = payPrincipal <= sched ? payPrincipal : sched;
                    loanScheduledPrincipal[unionAddr][loanId] = sched - cut;
                    scheduledPrincipalByDate[unionAddr][ln.token][ln.maturityTs] -= cut;
                }
            }
        }
        emit LoanRepaid(unionAddr, loanId, payInterest, payPrincipal);
    }

    function transferLoan(
        address unionAddr,
        bytes32 loanId,
        address newBorrower,
        uint16 newRateBP,
        uint40 newMaturityTs
        ) external whenNotPaused onlyOracleOrLeader(unionAddr) {
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(newBorrower != address(0), "newBorrower=0");
        require(ln.drawdownTs != 0, "loan !exist");
        require(!ln.defaulted && !ln.liquidated, "closed");

        uint40 endTs = uint40(block.timestamp);
        uint256 elapsed = uint256(endTs - ln.drawdownTs);
        uint256 accrued = (uint256(ln.principal) * ln.rateBP * elapsed) / (HUNDRED_PERCENT_BP * YEAR);

        if (ln.interestPaid < accrued) {
            uint256 shortfall = accrued - ln.interestPaid;
            uint256 tol = (uint256(ln.principal) * ln.rateBP * CARRYOVER_WINDOW) / (HUNDRED_PERCENT_BP * YEAR);
            require(shortfall <= tol, "interest not settled (>3d)");
        }

        address oldBorrower = ln.borrower;
        ln.borrower = newBorrower; // rollover supported by equal old/new
        ln.rateBP = newRateBP;
        ln.maturityTs = newMaturityTs;

        emit LoanTransferred(unionAddr, loanId, oldBorrower, newBorrower, newRateBP, newMaturityTs);
    }

    function markDefault(address unionAddr, bytes32 loanId)
        external
        onlyOracleOrLeader(unionAddr)
        {
            IFundCore.Loan storage ln = loans[unionAddr][loanId];
            require(ln.createTs != 0, "loan !exist");
            require(!ln.defaulted && !ln.liquidated, "closed");

            // (optional) grace window after maturity; uncomment if you want to enforce the 41 days
            // if (ln.maturityTs != 0) {
            //     require(block.timestamp >= uint256(ln.maturityTs) + 41 days, "too early");
            // }

        address token = ln.token;
        bytes32 lt    = ln.loanType;

        // ── 1) principal remaining at default ────────────────────────────────────
        uint256 principalRemaining = ln.principal > ln.principalPaid
            ? uint256(ln.principal) - uint256(ln.principalPaid)
            : 0;

        // ── 2) decrement utilization counters (per-union + per-loanType) ─────────
        if (principalRemaining > 0) {
            // per-union utilization for rate model
            uint256 ub = unionBorrowsAgg[unionAddr][token];
            unionBorrowsAgg[unionAddr][token] = principalRemaining >= ub ? 0 : (ub - principalRemaining);

            // per-loanType borrow counter (if you added totalBorrows to JuniorMarket)
            JuniorMarket storage jm = junior[unionAddr][token][lt];
            uint256 tb = jm.totalBorrows;
            jm.totalBorrows = principalRemaining >= tb ? 0 : (tb - principalRemaining);
        }

        // ── 3) haircut waterfall: Junior (matching type) then Senior ─────────────
        uint256 juniorApplied = _applyLossJunior(junior[unionAddr][token][lt], principalRemaining);
        uint256 remaining     = principalRemaining > juniorApplied ? (principalRemaining - juniorApplied) : 0;

        uint256 seniorApplied = 0;
        if (remaining > 0) {
            seniorApplied = _applyLossSenior(senior[token], remaining);
        }

        // ── 4) close the loan ────────────────────────────────────────────────────
        ln.defaulted  = true;
        ln.liquidated = true;

        // remove any scheduled amount for this loan (was never repaid)
        if (ln.maturityTs != 0) {
            uint256 sched = loanScheduledPrincipal[unionAddr][loanId];
            if (sched > 0) {
                loanScheduledPrincipal[unionAddr][loanId] = 0;
                scheduledPrincipalByDate[unionAddr][ln.token][ln.maturityTs] -= sched;
            }
        }

        emit LoanDefaulted(unionAddr, loanId, juniorApplied, seniorApplied);
    }

    // ---------- Loan Maturity lifecycle ----------
    function reportMaturity(address unionAddr, bytes32 loanId, uint40 maturityTs)
        external
        onlyOracleOrLeader(unionAddr)
        {
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(ln.createTs != 0, "loan !exist");
        require(ln.maturityTs == 0, "maturity set");
        require(maturityTs >= ln.createTs, "maturity<drawdown");

        ln.maturityTs = maturityTs;

        // schedule remaining principal for this loan at maturity
        uint256 remaining = uint256(ln.principal) > uint256(ln.principalPaid)
            ? uint256(ln.principal) - uint256(ln.principalPaid)
            : 0;
        if (remaining > 0) {
            scheduledPrincipalByDate[unionAddr][ln.token][maturityTs] += remaining;
            loanScheduledPrincipal[unionAddr][loanId] = remaining;
        }

        emit MaturityReported(unionAddr, loanId, maturityTs);
    }

    function creditRecovery(address unionAddr, bytes32 loanId, uint256 recovered)
        external
        onlyOracleOrLeader(unionAddr)
        {
        require(recovered > 0, "amount=0");
        IFundCore.Loan storage ln = loans[unionAddr][loanId];
        require(ln.createTs != 0, "loan !exist");
        require(ln.defaulted, "!defaulted"); // we don't care if liquidated is already true

        // ⚠️ No token movement here. Caller must have already sent `recovered` tokens
        // to this contract prior to calling this function (or in the same tx via a hook).

        // For now, credit everything to the matching junior bucket.
        // If you want to overflow to senior, add logic using tracked haircut amounts.
        junior[unionAddr][ln.token][ln.loanType].cash += recovered;

        emit RecoveryCredited(unionAddr, loanId, recovered);
    }

    // ---------- Withdraw lifecycle ----------
    function creditMaturedRepayments(
        address unionAddr,
        address token,
        uint40[] calldata dates   // pass only dates <= now
        ) external onlyOracleOrLeader(unionAddr) {
        uint256 total;
        for (uint256 i = 0; i < dates.length; i++) {
            uint40 d = dates[i];
            require(d <= block.timestamp, "date>now");
            uint256 amt = scheduledPrincipalByDate[unionAddr][token][d];
            if (amt == 0) continue;
            scheduledPrincipalByDate[unionAddr][token][d] = 0;
            maturedCreditByUnionToken[unionAddr][token] += amt;
            total += amt;
            emit MaturitiesCredited(unionAddr, token, d, amt);
        }
        // no return; state + events are enough
    }

    // ---------- Minimal views needed by tests (most moved to Viewer) ----------
    function getSeniorMarket(address token) external view returns (IFundCore.MarketLite memory m) {
        SeniorMarket storage s = senior[token];
        m = IFundCore.MarketLite({
            cash: s.cash,
            index: s.index == 0 ? GenericFundMathLib.RAY : s.index,
            totalShares: s.totalShares,
            totalBorrows: s.totalBorrows,
            claimablePrincipal: s.claimablePrincipal
        });
    }

    function getJuniorMarket(address unionAddr, address token, bytes32 loanType) external view returns (IFundCore.MarketLite memory m) {
        JuniorMarket storage j = junior[unionAddr][token][loanType];
        m = IFundCore.MarketLite({
            cash: j.cash,
            index: j.index == 0 ? GenericFundMathLib.RAY : j.index,
            totalShares: j.totalShares,
            totalBorrows: j.totalBorrows,     
            claimablePrincipal: j.claimablePrincipal
        });
    }

    function getInvestorSenior(address token, address investor) external view returns (IFundCore.InvestorLite memory out) {
        Investor storage inv = seniorInv[token][investor];
        out = IFundCore.InvestorLite({shares: inv.shares, locked: inv.pending + inv.claimable, pending: inv.pending});
    }

    function getInvestorJunior(address unionAddr, address token, bytes32 loanType, address investor) external view returns (IFundCore.InvestorLite memory out) {
        Investor storage inv = juniorInv[unionAddr][token][loanType][investor];
        out = IFundCore.InvestorLite({shares: inv.shares, locked: inv.pending + inv.claimable, pending: inv.pending});
    }

    function rateParamsFor(address unionAddr, address token)
        external
        view
        returns (uint16 baseRateBP, uint16 kinkUtilBP, uint16 slope1BP, uint16 slope2BP, uint16 maxRateBP)
        {
        GenericFundMathLib.RateParams memory p = rateParamsByUnionToken[unionAddr][token];
        return (p.baseRateBP, p.kinkUtilBP, p.slope1BP, p.slope2BP, p.maxRateBP);
    }

    // ── Views (nice-to-haves) ──
    function isUnionActive(address unionAddr) external view returns (bool) {
        return unions[unionAddr].active;
    }
    function getUnionName(address unionAddr) external view returns (string memory) {
        return unions[unionAddr].name;
    }
    function getFundTypes(address unionAddr) external view returns (bytes32[] memory) {
        return unions[unionAddr].fundTypes;
    }
    function getFundTypeName(address unionAddr, bytes32 loanType) external view returns (string memory) {
        return unions[unionAddr].fundTypeName[loanType];
    }
    function isFundTypeAllowed(address unionAddr, bytes32 loanType) external view returns (bool) {
        return unions[unionAddr].isFundType[loanType];
    }
    function aggregateBorrowsForUnionToken(address unionAddr, address token) external view returns (uint256) {
        return unionBorrowsAgg[unionAddr][token];
    }
    function getUnionCapBasePublic(address unionAddr, address token) external view returns (uint256) {
        return juniorMaxSum[unionAddr][token]; // same meaning as v1
    }
}
