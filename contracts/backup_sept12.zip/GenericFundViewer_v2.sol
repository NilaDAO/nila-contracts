// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import { Math } from "@openzeppelin/contracts/utils/math/Math.sol";
import { GenericFundMathLib } from "./GenericFundMathLib.sol";

interface IFundCore {
    enum Tranche { JUNIOR, SENIOR }

    struct MarketLite {
        uint128 supplyIndex;
        uint256 totalShares;
        uint256 totalBorrows;
        uint256 maxDeposited;
    }

    struct InvestorLite {
        uint256 shares;
        uint128 entryIndex;
        uint128 unclaimed;
        uint256 lockedShares;
    }

    struct Loan {
        address borrower;
        address token;
        uint128 principal;
        uint16  rateBP;
        uint40  drawdownTs;
        uint40  harvestTs;
        uint40  maturityTs;
        uint128 repaid;
        uint128 interestPaid;
        bool    liquidated;
        bool    defaulted;
        bytes32 loanType;
        bytes32 paramsHash;
    }

    // core views used
    function getJuniorMarketLite(address unionAddr, address token, bytes32 loanType) external view returns (MarketLite memory);
    function getSeniorMarketLite(address token) external view returns (MarketLite memory);

    function investorLite(Tranche tranche, address unionAddr, address token, bytes32 loanType, address investor ) external view returns (uint256 shares, uint256 entryIndex, uint256 unclaimed, uint256 lockedShares);

    function getLoan(address unionAddr, bytes32 loanId) external view returns (Loan memory);
    function getUnionCapBasePublic(address unionAddr, address token) external view returns (uint256);
    function seniorCap(address unionAddr, address token) external view returns (uint256);
    function aggregateBorrowsForUnionToken(address unionAddr, address token) external view returns (uint256);
    function getLoansByBorrower(address borrower) external view returns (bytes32[] memory);
    function oracleSigners(address signer) external view returns (bool);
    function getLoanTypesForUnionToken(address unionAddr, address token) external view returns (bytes32[] memory);
    function getTokenListJunior(address unionAddr) external view returns (address[] memory);
    function getTokenListSenior() external view returns (address[] memory); 
    function rateParamsFor(address unionAddr, address token) external view returns ( uint16 baseRateBP, uint16 kinkUtilBP, uint16 slope1BP, uint16 slope2BP, uint16 maxRateBP );    
    function getLiquidityBufferState(address token) external view returns (
        uint16 safetyBP,
        uint256 safetyFloor,
        uint256 claimable,
        uint256 totalPending,
        uint256 hardStop,
        uint256 queueHead,
        uint256 queueLen
    );
}

contract GenericFundViewer {
    // ── constants ──────────────────────────────────────────────────────────────
    uint256 constant RAY = 1e27;

    // EIP-712 (OZ v4 domain shape)
    bytes32 private constant EIP712_DOMAIN_TYPEHASH =
        keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
    bytes32 private constant NAME_HASH    = keccak256("GenericFund");
    bytes32 private constant VERSION_HASH = keccak256("1.3"); // must match historical core

    // typed data typehashes
    bytes32 private constant VOUCHER_TYPEHASH =
        keccak256("Voucher(address borrower,address union,address token,uint256 maxAmount,uint16 minRateBP,uint256 nonce,bytes32 loanType,bytes32 paramsHash)");
    bytes32 private constant QUOTE1155_TYPEHASH =
        keccak256("Quote1155(address union,address token,bytes32 loanType,address investor,address collection,uint256 id,uint256 amount1155,uint256 quoteAmount,uint256 nonce,uint40 expiry)");

    IFundCore public immutable core;

    constructor(address core_) { core = IFundCore(core_); }

    // ── domain helpers ────────────────────────────────────────────────────────
    function _domainSeparatorFor(address coreAddr) internal view returns (bytes32) {
        return keccak256(
            abi.encode(
                EIP712_DOMAIN_TYPEHASH,
                NAME_HASH,
                VERSION_HASH,
                block.chainid,
                coreAddr
            )
        );
    }

    function _hashTypedDataFor(address coreAddr, bytes32 structHash) internal view returns (bytes32) {
        return keccak256(abi.encodePacked("\x19\x01", _domainSeparatorFor(coreAddr), structHash));
    }

    // ── rich read helpers (unchanged behaviour) ───────────────────────────────
    function getBorrowerInfo(address unionAddr, bytes32 loanId)
        external view
        returns (
            address borrower,
            address token,
            bytes32 loanType,
            uint256 principal,
            uint256 principalRepaid,
            uint16  rateBP,
            uint40  dueDate,
            bool    closed,
            bool    defaulted,
            uint256 outstanding
        )
        {
        IFundCore.Loan memory ln = core.getLoan(unionAddr, loanId);

        borrower        = ln.borrower;
        token           = ln.token;
        loanType        = ln.loanType;
        principal       = ln.principal;
        principalRepaid = ln.repaid;
        rateBP          = ln.rateBP;
        dueDate         = ln.maturityTs;
        closed          = ln.liquidated;
        defaulted       = ln.defaulted;

        uint40 nowOrMat = ln.maturityTs == 0 ? uint40(block.timestamp) : ln.maturityTs;
        uint256 elapsed = uint256(nowOrMat - ln.drawdownTs);

        uint256 interestAccrued = GenericFundMathLib.accruedInterest(
            ln.principal, rateBP, elapsed, 365 days
        );
        uint256 unpaidInterest = interestAccrued > ln.interestPaid ? (interestAccrued - ln.interestPaid) : 0;
        uint256 principalDue   = principal > principalRepaid ? (principal - principalRepaid) : 0;
        outstanding = principalDue + unpaidInterest;
    }

    function getInvestorInfo(
        IFundCore.Tranche tranche,
        address unionAddr,
        address token,
        bytes32 loanType,
        address investorAddr
        ) external view returns (uint256 shares, uint256 locked, uint256 pending) {
        (uint256 sh, uint256 entry, uint256 unclaimed, uint256 locked_) =
            core.investorLite(tranche, unionAddr, token, loanType, investorAddr);

        shares = sh;
        locked = locked_;

        // pick the right market index
        uint256 idx = tranche == IFundCore.Tranche.JUNIOR
            ? core.getJuniorMarketLite(unionAddr, token, loanType).supplyIndex
            : core.getSeniorMarketLite(token).supplyIndex;

        if (sh == 0 || idx == 0) return (shares, locked, unclaimed);
        uint256 delta = idx > entry ? (idx - entry) : 0;
        pending = unclaimed + Math.mulDiv(sh, delta, RAY);
    }

    function canBorrow(address unionAddr, address token, uint256 amount) external view returns (bool) {
        // using viewer’s computed cap to avoid relying on a core helper
        uint256 cap = getBorrowCap(unionAddr, token);
        return amount <= cap;
    }

    function getLiquidityBuffer(address token)
        external view
        returns (uint16 safetyBP, uint256 safetyFloor, uint256 cash, uint256 claimablePending, uint256 hardStop, uint256 queueHead, uint256 queueLen)
    { return core.getLiquidityBufferState(token); }


    function getRateParams(address unionAddr, address token) external view returns (uint16 baseRateBP, uint16 kinkUtilBP, uint16 slope1BP, uint16 slope2BP, uint16 maxRateBP) {
        return core.rateParamsFor(unionAddr,token);
    }

    function getRemainingBorrowCap(address unionAddr, address token) external view returns (uint256 remaining) {
        uint256 cap = getBorrowCap(unionAddr, token);
        uint256 borrows = core.aggregateBorrowsForUnionToken(unionAddr, token);
        return cap > borrows ? cap - borrows : 0;
    }

    function getLoansByBorrower(address borrower) external view returns (bytes32[] memory) {
        return core.getLoansByBorrower(borrower);
    }

    function isOracleSigner(address signer) external view returns (bool) {
        return core.oracleSigners(signer);
    }

    function getLoanTypesForUnionToken(address unionAddr, address token) external view returns (bytes32[] memory) {
        return core.getLoanTypesForUnionToken(unionAddr, token);
    }

    function getTokenListJunior(address unionAddr) external view returns (address[] memory) {
        return core.getTokenListJunior(unionAddr);
    }

    function getTokenListSenior() external view returns (address[] memory) {
        return core.getTokenListSenior();
    }

    function getBorrowCap(address unionAddr, address token) public view returns (uint256 cap) {
        uint256 unionBase = core.getUnionCapBasePublic(unionAddr, token);
        uint256 senior    = core.seniorCap(unionAddr, token);
        cap = 2 * (unionBase + senior);
    }

    function getFundTotalsByTranche(
        IFundCore.Tranche tranche,
        address unionAddr,
        address token,
        bytes32 loanType
        ) external view returns (uint256 totalDeposits, uint256 totalBorrows) {
        if (tranche == IFundCore.Tranche.JUNIOR) {
            IFundCore.MarketLite memory m = core.getJuniorMarketLite(unionAddr, token, loanType);
            totalDeposits = m.supplyIndex == 0 ? 0 : Math.mulDiv(m.totalShares, m.supplyIndex, 1e27);
            totalBorrows  = m.totalBorrows;
        } else {
            IFundCore.MarketLite memory s = core.getSeniorMarketLite(token);
            totalDeposits = s.supplyIndex == 0 ? 0 : Math.mulDiv(s.totalShares, s.supplyIndex, 1e27);
            totalBorrows  = 0;
        }
    }

    function getLiquidityBufferState(address token)
        external view
        returns (
            uint16 safetyBP,
            uint256 safetyFloor,
            uint256 claimable,
            uint256 totalPending,
            uint256 hardStop,
            uint256 queueHead,
            uint256 queueLen
        )
        { return core.getLiquidityBufferState(token); 
    }

    function getLoan(address unionAddr, bytes32 loanId) external view returns (IFundCore.Loan memory) {
        return core.getLoan(unionAddr, loanId);
    }

    // ── rate preview using core params ─────────────────────────────────────────
    function previewRateBP(address unionAddr, address token, uint256 amount) external view returns (uint16) {
        uint16 base; uint16 kink; uint16 s1; uint16 s2; uint16 max;

        // Prefer per-union params if Core exposes them
        try core.rateParamsFor(unionAddr, token) returns (uint16 b, uint16 k, uint16 _s1, uint16 _s2, uint16 m) {
            base = b; kink = k; s1 = _s1; s2 = _s2; max = m;
        } catch {
            // Fallback: legacy per-token params
            (base, kink, s1, s2, max) = core.rateParamsFor(unionAddr,token);
        }

        uint256 cap     = getBorrowCap(unionAddr, token);
        uint256 borrows = core.aggregateBorrowsForUnionToken(unionAddr, token);

        GenericFundMathLib.RateParams memory p = GenericFundMathLib.RateParams({
            baseRateBP: base, kinkUtilBP: kink, slope1BP: s1, slope2BP: s2, maxRateBP: max
        });
        return GenericFundMathLib.quoteRateBP(p, cap, borrows, amount);
    }

    // ── EIP-712 recovery (fields signatures matching Core) ─────────────────────
    function recoverVoucherSigner(
        address coreAddr,
        address borrower,
        address unionAddr,
        address token,
        uint256 maxAmount,
        uint16  minRateBP,
        uint256 nonce,
        bytes32 loanType,
        bytes32 paramsHash,
        bytes calldata sig
        ) external view returns (address) {
        bytes32 structHash = keccak256(abi.encode(
            VOUCHER_TYPEHASH,
            borrower, unionAddr, token, maxAmount, minRateBP, nonce, loanType, paramsHash
        ));
        bytes32 digest = _hashTypedDataFor(coreAddr, structHash);
        return ECDSA.recover(digest, sig);
    }

    function recoverQuote1155Signer(
        address coreAddr,
        address unionAddr,
        address token,
        bytes32 loanType,
        address investor,
        address collection,
        uint256 id,
        uint256 amount1155,
        uint256 quoteAmount,
        uint256 nonce,
        uint40  expiry,
        bytes calldata sig
        ) external view returns (address) {
        bytes32 structHash = keccak256(abi.encode(
            QUOTE1155_TYPEHASH,
            unionAddr, token,
            loanType,
            investor,
            collection,
            id,
            amount1155,
            quoteAmount,
            nonce,
            expiry
        ));
        bytes32 digest = _hashTypedDataFor(coreAddr, structHash);
        return ECDSA.recover(digest, sig);
    }

    function version() external pure returns (string memory) {
        return "v1.3";
    }
}