// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
 * InputFundUpgradeable – v3.0 (adds share‑index interest accrual)
 * ‑ Dynamic supply index per token (ray precision 1e27)
 * ‑ Investors receive ERC‑4626‑like shares (non‑transferable for now)
 * ‑ Interest from loan repayments is distributed by bumping the index
 */

import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol";
import "@openzeppelin/contracts-upgradeable/utils/cryptography/EIP712Upgradeable.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/token/ERC721/IERC721.sol";   // or ERC1155

contract InputFundUpgradeable is
    Initializable,
    OwnableUpgradeable,
    UUPSUpgradeable,
    ReentrancyGuardUpgradeable,
    PausableUpgradeable,
    EIP712Upgradeable
{
    using SafeERC20 for IERC20Metadata;

    uint256 private constant RAY = 1e27;
    IERC721 constant hasNFT = IERC721(0x663DC13009D004aF3654a45f22A215De71633918);

    /*//////////////////////////////////////////////////////////////
                                EVENTS
    //////////////////////////////////////////////////////////////*/

    event TokenAdded(address token);
    event TokenRevoked(address token);
    event Invest(address indexed investor, address indexed token, uint256 amount, uint256 sharesMinted);
    event Withdraw(address indexed investor, address indexed token, uint256 amount, uint256 sharesBurned);
    event LoanClaimed(uint256 indexed loanId, address indexed borrower, address indexed token, uint256 amount);
    event LoanRepaid(uint256 indexed loanId, uint256 repaid, uint256 remainingPrincipal);
    event InterestDistributed(address indexed token, uint256 interest);
    event BaseRateChanged(uint256 oldRateBP, uint256 newRateBP);
    event HarvestMarked(uint256 loanId, uint256 harvestTs, uint256 dueTs);
    event LoanLiquidated(uint256 loanId, uint256 seizedUnderlying, uint256 owed);

    /*//////////////////////////////////////////////////////////////
                                STRUCTS
    //////////////////////////////////////////////////////////////*/

    struct Market {
        uint256 supplyIndex;   // cumulative per‑share index (ray)
        uint256 totalShares;   // aggregate investor shares
        uint256 totalBorrows;  // outstanding loan principal
    }

    struct LoanVoucher {
        uint256 loanId;
        address borrower;
        address token;
        uint256 amount;
        uint256 interestBP; // per‑loan flat interest (basis points)
    }

    struct Loan {
        address borrower;
        address token;
        uint256 principal;
        uint256 interestBP;
        uint256 dueDate;
        uint256 repaid;
        bool    closed;
    }

    /*//////////////////////////////////////////////////////////////
                                STORAGE
    //////////////////////////////////////////////////////////////*/

    address public oracleSigner;
    string public fundName;
    string public fundType;
    uint256 public baseRateBP;            // lender base rate (basis‑points)
    uint256 public harvestGrace;          // secs, e.g. 14 days

    mapping(address => Market) public markets;                   // token ⇒ market data
    mapping(address => mapping(address => uint256)) public userShares; // user ⇒ token ⇒ shares
    mapping(address => bool) public investorFrozen;   // wallet ⇒ frozen?

    mapping(uint256 => Loan) public loans;
    mapping(address => bool) public whitelistedTokens;
    address[] public tokenList;
    mapping(address => uint256[]) private loansByBorrower;

    /* === modifiers === */
    modifier denyWithdrawal(address token) {
        bool solvent = !_insolvent(token);
        bool landTitle = hasNFT.balanceOf(msg.sender) > 0;  // 👈 NFT gate
        require(solvent || !landTitle, "allow, has no landtitle or pool is solvent");
        _;
    }

    modifier notFrozen() {
        require(!investorFrozen[msg.sender], "funds frozen");
        _;
    }

    modifier onlyWhitelisted(address token) {
        require(whitelistedTokens[token], "token is not accepted to this pool");
        _;
    }

    modifier onlyOracle() {
        require(msg.sender == oracleSigner, "not oracle");
        _;
    }

    /*//////////////////////////////////////////////////////////////
                          INITIALIZER / UPGRADE
    //////////////////////////////////////////////////////////////*/

    function initialize(
        string calldata _fundName,
        string calldata _fundType,
        address[] calldata tokens,
        address _oracleSigner,
        uint16   _baseRateBP,
        address _union
    ) external initializer {
        oracleSigner = _oracleSigner;
        baseRateBP   = _baseRateBP;
        fundName     = _fundName;
        fundType     = _fundType;

        __Ownable_init(_union);
        __UUPSUpgradeable_init();
        __Pausable_init();
        __ReentrancyGuard_init();
        __EIP712_init("InputFundUpgradeable", "3");

        for (uint256 i; i < tokens.length; ++i) {
            tokenList.push(tokens[i]);
            whitelistedTokens[tokens[i]] = true;
        }
    }

    function _authorizeUpgrade(address newImplementation) internal override onlyOwner {}

    /*//////////////////////////////////////////////////////////////
                              MARKET HELPERS
    //////////////////////////////////////////////////////////////*/

    /// @dev returns true when pool assets can’t cover all deposits
    function _insolvent(address token) internal view returns (bool) {
        Market storage m = markets[token];

        uint256 cash   = IERC20Metadata(token).balanceOf(address(this));
        uint256 liab   = m.totalShares * m.supplyIndex / RAY; // deposits + interest
        uint256 assets = cash + m.totalBorrows;               // cash + outstanding loans

        return assets < liab;
    }

    function _ensureMarket(address token) internal {
        if (markets[token].supplyIndex == 0) {
            markets[token].supplyIndex = RAY; // 1×
        }
    }

    /// @dev distribute freshly‑received interest by bumping the index
    function _distributeInterest(address token, uint256 interest) internal {
        Market storage m = markets[token];
        if (interest == 0 || m.totalShares == 0) return;
        // Δindex = interest / totalShares (in ray)
        uint256 delta = interest * RAY / m.totalShares;
        m.supplyIndex += delta;
        emit InterestDistributed(token, interest);
    }

    /*//////////////////////////////////////////////////////////////
                               ADMIN
    //////////////////////////////////////////////////////////////*/

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function addToken(address token) external onlyOwner {
        require(!whitelistedTokens[token], "already");
        whitelistedTokens[token] = true;
        tokenList.push(token);
        _ensureMarket(token);
        emit TokenAdded(token);
    }

    function revokeToken(address token) external onlyOwner {
        require(whitelistedTokens[token], "!exists");
        whitelistedTokens[token] = false;
        // swap‑pop list
        uint256 len = tokenList.length;
        for (uint256 i; i < len; ++i) {
            if (tokenList[i] == token) {
                tokenList[i] = tokenList[len - 1];
                tokenList.pop();
                break;
            }
        }
        emit TokenRevoked(token);
    }

    /*//////////////////////////////////////////////////////////////
                              INVEST / WITHDRAW
    //////////////////////////////////////////////////////////////*/

        /// @dev internal deposit routine used by both invest() forms
    function _invest(address account, address token, uint256 amount) internal {
        _ensureMarket(token);
        Market storage m = markets[token];

        IERC20Metadata(token).safeTransferFrom(account, address(this), amount);

        uint256 shares = amount * RAY / m.supplyIndex; // shares = cash / index
        require(shares > 0, "zero shares");

        m.totalShares += shares;
        userShares[account][token] += shares;

        emit Invest(account, token, amount, shares);
    }

    /// @notice standard deposit (requires prior ERC‑20 approve)
    function invest(address token, uint256 amount) external whenNotPaused onlyWhitelisted(token) nonReentrant notFrozen {
        _invest(msg.sender, token, amount);
    }
        function investWithPermit(
        address token,
        uint256 amount,
        uint256 deadline,
        uint8 v,
        bytes32 r,
        bytes32 s
    ) external whenNotPaused onlyWhitelisted(token) nonReentrant {
        IERC20Permit(token).permit(msg.sender, address(this), amount, deadline, v, r, s);
        _invest(msg.sender, token, amount); // reuse logic without external call
    }

    /// @notice withdraw given amount of underlying (redeems corresponding shares)
    function withdraw(address token, uint256 amount) external whenNotPaused nonReentrant onlyWhitelisted(token) notFrozen {
        _ensureMarket(token);
        Market storage m = markets[token];

        uint256 shares = amount * RAY / m.supplyIndex;
        require(shares > 0 && shares <= userShares[msg.sender][token], "insufficient shares");

        m.totalShares -= shares;
        userShares[msg.sender][token] -= shares;

        IERC20Metadata(token).safeTransfer(msg.sender, amount);
        emit Withdraw(msg.sender, token, amount, shares);
    }

    /// @notice redeem exact shares → underlying amount
    function redeem(address token, uint256 shares) external whenNotPaused nonReentrant onlyWhitelisted(token) notFrozen {
        _ensureMarket(token);
        Market storage m = markets[token];
        require(shares > 0 && shares <= userShares[msg.sender][token], "bad shares");

        uint256 amount = shares * m.supplyIndex / RAY;

        m.totalShares -= shares;
        userShares[msg.sender][token] -= shares;

        IERC20Metadata(token).safeTransfer(msg.sender, amount);
        emit Withdraw(msg.sender, token, amount, shares);
    }

    /*//////////////////////////////////////////////////////////////
                        LOAN CLAIM & REPAYMENT
    //////////////////////////////////////////////////////////////*/

    bytes32 private constant _LOAN_VOUCHER_TYPEHASH = keccak256(
        "LoanVoucher(uint256 loanId,address borrower,address token,uint256 amount,uint256 interestBP)"
    );

    /// @notice helper to set the time (in seconds) the borrower has to pay back after harvest is detected
    function setHarvestGrace(uint256 secs) external onlyOwner {
        harvestGrace = secs;
    }
    
    /// @notice method called by oracle to set a harvest date and count the clock to payback
    function markHarvest(uint256 loanId) external onlyOracle {
    Loan storage ln = loans[loanId];
    require(!ln.closed, "closed");
    uint256 harvestTs = block.timestamp;
    ln.dueDate = harvestTs + harvestGrace;   // overwrite previous due
    emit HarvestMarked(loanId, harvestTs, ln.dueDate);
}

    function _hashVoucher(LoanVoucher memory v) private view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(
                _LOAN_VOUCHER_TYPEHASH,
                v.loanId,
                v.borrower,
                v.token,
                v.amount,
                v.interestBP
            )));
    }

    function claimLoan(LoanVoucher calldata v, bytes calldata sig) external whenNotPaused nonReentrant onlyWhitelisted(v.token) {
        // 1) check if the voucher borrower is the caller
        require(v.borrower == msg.sender, "not borrower");

        // 1) verify oracle‘s signature
        bytes32 digest = _hashVoucher(v);
        address signer = ECDSA.recover(digest, sig);
        require(signer == oracleSigner, "bad sig");

        // 2) liquidity check
        uint256 available = IERC20Metadata(v.token).balanceOf(address(this));
        require(available >= v.amount, "insufficient liquidity");

        loans[v.loanId] = Loan({
            borrower: v.borrower,
            token: v.token,
            principal: v.amount,
            interestBP: v.interestBP,
            dueDate: 0,
            repaid: 0,
            closed: false
            });

        markets[v.token].totalBorrows += v.amount;

        IERC20Metadata(v.token).safeTransfer(v.borrower, v.amount);

        // lock investments untill repaid (IN ONLY THIS CONTRACT)
        investorFrozen[v.borrower] = true; // lock their pool assets
        loansByBorrower[msg.sender].push(v.loanId);

        emit LoanClaimed(v.loanId, v.borrower, v.token, v.amount);
    }

    function repayLoan(uint256 loanId, uint256 amount) external whenNotPaused nonReentrant {
        Loan storage ln = loans[loanId];
        require(!ln.closed, "closed");

        IERC20Metadata(ln.token).safeTransferFrom(msg.sender, address(this), amount);
        ln.repaid += amount;

        uint256 owed = ln.principal + (ln.principal * ln.interestBP) / 10_000;
        uint256 remainingPrincipal = ln.principal > ln.repaid ? ln.principal - ln.repaid : 0;

        // update borrow stats
        uint256 principalReduction = remainingPrincipal == 0 ? ln.principal : amount; // approximation
        if (markets[ln.token].totalBorrows >= principalReduction) {
            markets[ln.token].totalBorrows -= principalReduction;
        } else {
            markets[ln.token].totalBorrows = 0;
        }

        if (ln.repaid >= owed) {
            ln.closed = true;
            // unlock investments
            investorFrozen[msg.sender] = false; // works same as deleting
            uint256 interestPaid = owed - ln.principal;
            _distributeInterest(ln.token, interestPaid);
        }
        emit LoanRepaid(loanId, amount, remainingPrincipal);
    }

    /// @notice anyone can call once past dueDate
    function liquidateDelinquent(uint256 loanId) external nonReentrant {
        Loan storage ln = loans[loanId];
        require(!ln.closed, "closed");
        require(block.timestamp > ln.dueDate, "not late");

        uint256 owed = ln.principal + (ln.principal * ln.interestBP) / 10_000 - ln.repaid;

        // 3a. seize borrower’s pool shares
        uint256 seized;
        Market storage m = markets[ln.token];
        uint256 borrowerShares = userShares[ln.borrower][ln.token];
        if (borrowerShares > 0) {
            uint256 value = borrowerShares * m.supplyIndex / RAY;
            uint256 burnShares = value >= owed ? owed * RAY / m.supplyIndex : borrowerShares;

            // burn & reduce
            m.totalShares     -= burnShares;
            userShares[ln.borrower][ln.token] -= burnShares;

            uint256 underlying = burnShares * m.supplyIndex / RAY;
            seized = underlying;
            owed   = owed > underlying ? owed - underlying : 0;
        }

        /// USE NILA SWEEPER TO REMOVE FUNDS FROM OTHER CONTRACTS (NOT IMPLEMENTED)
        // 3b. *Optional* hook: pull funds from other contracts owned by same address
        //    (requires borrower to have approved this fund on those tokens)
        //    if (owed > 0) { _seizeExternal(ln.borrower, ln.token, owed); }

        // 3c. loan is lowered with seized amount, but not removed untill owed == 0
        ln.repaid += seized;
        if (owed == 0) {
            ln.closed = true;
            // unlock investments
            investorFrozen[msg.sender] = false; // works same as deleting
            uint256 interest = ln.repaid > ln.principal ? ln.repaid - ln.principal : 0;
            _distributeInterest(ln.token, interest);
        }

        emit LoanLiquidated(loanId, seized, owed);
    }

    /*//////////////////////////////////////////////////////////////
                               VIEWS
    //////////////////////////////////////////////////////////////*/

    /// @notice hash helper for off‑chain voucher signing tools
    function getInspectContract() external view returns (
        bytes32 typehash,
        address oracle
        ) {
        return (
            _LOAN_VOUCHER_TYPEHASH,
            oracleSigner
            );
    }
    
    function previewRedeem(address token, uint256 shares) external view returns (uint256) {
        uint256 idx = markets[token].supplyIndex;
        return shares * idx / RAY;
    }

    function balanceOf(address user, address token) external view returns (uint256 underlying) {
        return userShares[user][token] * markets[token].supplyIndex / RAY;
    }

    function loanStatus(uint256 loanId) external view returns (
        address borrower,
        address token,
        uint256 principal,
        uint256 repaid,
        uint256 interestBP,
        uint256 dueDate,
        bool closed
    ) {
        Loan memory ln = loans[loanId];
        return (
            ln.borrower,
            ln.token,
            ln.principal,
            ln.repaid,
            ln.interestBP,
            ln.dueDate,
            ln.closed
        );
    }

    /// @notice hash helper for off‑chain voucher signing tools
    function getVoucherDigest(LoanVoucher calldata v) external view returns (bytes32) {
        return _hashVoucher(v);
    }

    /// @return list of all currently tracked ERC‑20s (whitelisted & revoked)
    function getTokenList() external view returns (address[] memory) {
        return tokenList;
    }

    /// @notice pool totals (cash+lent) and outstanding borrows
    function getFundTotals(address token)
        external
        view
        returns (uint256 totalDeposits, uint256 totalBorrowed)
        {
            Market memory m = markets[token];
            // shares→underlying; if no market yet, both return 0
            totalDeposits = m.totalShares * m.supplyIndex / RAY;
            totalBorrowed = m.totalBorrows;
        }

    /**
     * @notice Caller’s position: underlying currently owed to them
     *         and the interest that has accrued but not yet withdrawn.
     * @return principalShares – raw share balance
     * @return pendingInterest – interest in underlying units
     *
     * pendingInterest = shares × (currentIndex – 1 RAY) / RAY
     * (assumes initial index was 1 RAY)
     */
    function getInvestorInfo(address token, address investor)
        external
        view
        returns (uint256 principalShares, uint256 pendingInterest, bool isFrozen)
        {
            Market memory m = markets[token];
            principalShares = userShares[investor][token];
            isFrozen = investorFrozen[investor];

            if (principalShares == 0) return (0,0,true);

            uint256 idxDiff = m.supplyIndex - RAY;
            pendingInterest = principalShares * idxDiff / RAY;
        }

    /**
     * @notice  Info for a specific loan plus pool/borrower flags
     * @dev     Pass the loanId you care about. Returns:
     *          – core loan struct values
     *          – outstanding principal+interest (owed)
     *          – isFrozen     → borrower’s shares locked?
     *          – poolInsolvent→ can the pool meet all withdrawals?
     */
    function getBorrowerInfo(uint256 loanId)
        external
        view
        returns (
            address borrower,
            address token,
            uint256 principal,
            uint256 repaid,
            uint256 interestBP,
            uint256 dueDate,
            bool    closed,
            uint256 outstanding,      // principal + flat interest – repaid
            bool    isFrozen,         // investorFrozen[borrower]
            bool    poolInsolvent,     // _insolvent(token)
            string  memory name     // name of fund
        )
    {
        Loan memory ln = loans[loanId];

        borrower   = ln.borrower;
        token      = ln.token;
        principal  = ln.principal;
        repaid     = ln.repaid;
        interestBP = ln.interestBP;
        dueDate    = ln.dueDate;
        closed     = ln.closed;

        uint256 flatInterest = principal * interestBP / 10_000;
        outstanding = principal + flatInterest > repaid
            ? principal + flatInterest - repaid
            : 0;

        isFrozen      = investorFrozen[borrower];
        poolInsolvent = _insolvent(token);
        name          = fundName;
    }
    
    /// @notice add a no-op canary
    function version() external pure returns (string memory) {
    return "v2.23";
    }

    /// @notice price per share (ray)
    function currentSupplyIndex(address token) external view returns (uint256) {
        return markets[token].supplyIndex;
    }

    /// @notice helper to preview mint (underlying → shares)
    function previewDeposit(address token, uint256 amount) external view returns (uint256 shares) {
        uint256 idx = markets[token].supplyIndex;
        return amount * RAY / idx;
    }

    /// @notice helper to preview withdraw (shares → underlying)
    function previewWithdraw(address token, uint256 shares) external view returns (uint256 amount) {
        uint256 idx = markets[token].supplyIndex;
        return shares * idx / RAY;
    }

    /// @notice Getter when user has resetted accounts  
    function getLoansByBorrower(address b) external view returns (uint256[] memory){ 
        return loansByBorrower[b]; 
    }

    /*//////////////////////////////////////////////////////////////
                            UPGRADEABLE GAP
    //////////////////////////////////////////////////////////////*/

    uint256[29] private __gap;
}

