// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import "@openzeppelin/contracts/token/ERC1155/IERC1155.sol";

interface IUnionLending {
    function getInvestorInfo(
        address unionAddr,
        address token,
        address investorAddr
    )
        external
        view
        returns (
            uint256 shares,
            uint256 pending,
            bool    isFrozen
        );
    function getLoansByBorrower(
        address borrower
    )
        external
        view
        returns ( bytes32[] memory ids);
}

contract NilaGrants {
    IERC20 public nIN;
    IERC721 public landTitle;
    IERC1155 public foodToken;    // Land title NFT registry (ERC-721)
    address public admin;
    IUnionLending public funding; // lending pool interface
    
    struct UserStats {
        uint256 engagementScore;
        uint256 accumulatedReward;
        uint256 lastClaimed;
    }
    
    mapping(address => UserStats) public stats;
    mapping(address => bool) public unions;

    uint256 private constant SCALE     = 1e18;      // fixed-point “1.0”
    uint256 public constant  MONTH     = 2629743; // ≈ (365.2425 days / 12) * 86400
    
    uint256 private constant MAX_EXT   = 1 * SCALE; // cap of 1
    uint256 private constant MAX_BAL   = 1 * SCALE; // cap of 1
    uint256 private constant MAX_SHR   = 3 * SCALE; // cap of 3
    // decay per month: e.g. DECAY_NUM/DECAY_DEN = 60/100 → score retains 60% each month
    uint256 private constant DECAY_NUM = 60;
    uint256 private constant DECAY_DEN = 100;
    uint256 public minimum;
    uint8 public multiplier;
    uint256 public currentMonth;

    event GrantClaimed(address indexed user, uint256 indexed month, uint256 reward);
    event MonthlyReset(uint256 newMonth);

    // Modifier to restrict access to admin/owner
    modifier onlyOwner() {
        require(msg.sender == admin, "Not admin");
        _;
    }
    constructor(address nilaTokenContract, address landTitleContract, address investmentContract, address foodTokenContract) {
        nIN = IERC20(nilaTokenContract);
        landTitle = IERC721(landTitleContract);
        foodToken = IERC1155(foodTokenContract);
        admin = msg.sender;
        currentMonth = getCurrentMonth();
        funding = IUnionLending(investmentContract);
        minimum = 1;
        multiplier = 3;
    }

    /// @dev one‐time per‐month decay + boost
    function scoring(
        address user,
        uint256 nmbfoodtokens,            // # food tokens held
        uint256 claimed,        // total grants ever claimed
        uint256 bal,            // current NILA balance
        uint256 shares          // Union-Lending shares
        ) internal view returns (uint256 decayed, uint256 boost) {
        // if this is the first call, seed them at “average”:
        if (stats[user].accumulatedReward == 0) {
            return (SCALE * multiplier, 0); // start at 3
        }

        // 1) Decay their old score by DECAY_NUM/DECAY_DEN
        uint256 old = stats[user].engagementScore;
        uint256 decayedValue = old * DECAY_NUM / DECAY_DEN;

        // 2) Compute extScore (food tokens)
        uint256 extRaw = nmbfoodtokens * SCALE / 10; // reaches 1 (=MAX) when 30 fds
        uint256 extS = extRaw > MAX_EXT ? MAX_EXT : extRaw;

        // 3) Compute balScore (spent ratio)
        uint256 balS;
        if (claimed == 0) {
            balS = SCALE;
        } else {
            uint256 spent = claimed > bal ? claimed - bal : 0;
            uint256 raw = spent * SCALE / claimed;
            balS = raw > MAX_BAL ? MAX_BAL : raw;
        }

        // 4) Compute shrScore
        uint256 shrRaw = shares / 1000; // reaches 3 (=MAX) when 30000 nIN invested
        uint256 shrS = shrRaw > MAX_SHR ? MAX_SHR : shrRaw;

        // 5) Sum & normalize to [0…1e18]
        uint256 norm = extS + balS + shrS;    // [0…5e18]

        // 6) Boost = (1 − decay) × norm
        uint256 boostValue = (DECAY_DEN - DECAY_NUM) * norm / DECAY_DEN;

        return (decayedValue,boostValue);
    }

    function getCurrentMonth() public view returns (uint256) {
        return block.timestamp / MONTH;
    }

    // ------------------------------------------------------------------
    // Calculate rewards
    // ------------------------------------------------------------------
    /// @notice 
    ///   check user balance for land title, Nila tokens, food tokens
    ///   check contracts
    function calculateRewards(
        address user,
        address union,
        uint256 nmbfoodtokens
        ) public view returns (uint256) {
        
        // check how many shares this user has (view function)
        (uint256 shares, , bool frozen) = funding.getInvestorInfo(union, address(nIN), user);
        require(!frozen, "this account is frozen, Nila doesnt send grants to frozen accounts.");

        // check if this user has borrowed from the contract
        bytes32[] memory ids = funding.getLoansByBorrower(user);
        uint8 activeBorrowPenalty = ids.length > 0 ? 10 : 1;

        // nIN balance
        uint256 bal = nIN.balanceOf(user);

        // how much has this user received in grants
        uint256 claimed = stats[user].accumulatedReward;

        // check if this user has been dormant
         (uint256 decayed,uint256 boost) = scoring(
            user,
            nmbfoodtokens,
            claimed,
            bal,
            shares
        );
        // Only update score when we claim a grant
        uint256 reward = decayed + boost;

        // use a 10% penalty when borrowing
        return reward / activeBorrowPenalty;
    }

    
    function claimGrant(address user,address union, uint256 nmbfoodtokens) external {
        uint256 currentMonthNow = getCurrentMonth();
        UserStats storage s = stats[user];

        // check if the union has signed up to participate in grants
        require(unions[union], "Your union has not joined the grant progam. Change union or ask your manager how to participate.");

        // check if the user already claimed this month
        require(s.lastClaimed != currentMonthNow, "You already claimed this month. Please wait for next month.");

        // check if the user has a land title
        require(landTitle.balanceOf(user) > 0, "You dont have a land title. Claim a free land title before collecting montly grants.");

        // calculate the reward for this user.
        uint256 reward = calculateRewards(user,union,nmbfoodtokens);
        // check if the pool has sufficient NILA tokens to cover the reward (otherwise unknown error)
        require(nIN.balanceOf(address(this)) > reward, "Your union pool has been depleted. Ask your manager how to get more grants.");

        s.accumulatedReward += reward;
        s.engagementScore    = reward;
        s.lastClaimed        = currentMonthNow;
        nIN.transfer(user, reward);

        emit GrantClaimed(user,currentMonthNow,reward);
    }

    /// @notice Update the ERC-1155 food token address
    function setFoodToken(address newFoodToken) external onlyOwner {
        require(newFoodToken != address(0), "zero address");
        foodToken = IERC1155(newFoodToken);
    }

    /// @notice Update the Union-lending pool interface address
    function setMultiplier(uint8 newMultiplier) external onlyOwner {
        multiplier = newMultiplier;
    }

    /// @notice Update the Union-lending pool interface address
    function setFundingContract(address newFunding) external onlyOwner {
        require(newFunding != address(0), "zero address");
        funding = IUnionLending(newFunding);
    }

    // Admin-only function to change the minimum token reward
    function AddUnions(address union) external onlyOwner {
        require(!unions[union], "Already registered");
        unions[union] = true;
    }
    // Admin-only function to change the minimum token reward
    function RemoveUnions(address union) external onlyOwner {
        require(unions[union], "Not registered");
        unions[union] = false;
    }

    // Admin-only function to change the minimum token reward
    function setMinimumTokens(uint256 newMin) external onlyOwner {
        minimum = newMin;
    }

    // Admin-only function to withdraw any leftover tokens
    function withdrawTokens(uint256 amount) external onlyOwner{
        require(nIN.transfer(admin, amount), "Token withdrawal failed");
    }

    // Helper function to check if the user has claimed
    function getGrantData(address user,address union, uint256 nmbfoodtokens) public view returns (uint256 reward,uint256 score,uint256 last) {
        uint256 currentMonthNow = getCurrentMonth();
        if(unions[union]){
            UserStats storage s = stats[user];
            if (s.lastClaimed != currentMonthNow){
                // recalculate the reward
                uint256 _reward = calculateRewards(user,union,nmbfoodtokens);
                return (_reward,s.engagementScore,s.lastClaimed);
            }
            return (s.engagementScore,s.engagementScore,s.lastClaimed);
        }
    }

    // Helper function to check the contract's NILA token balance
    function contractBalance() public view returns (uint256) {
        return nIN.balanceOf(address(this));
    }
}