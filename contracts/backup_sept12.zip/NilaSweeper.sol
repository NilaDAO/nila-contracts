// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/**
 * @title AssetSeizer (aka Sweeper)
 * @notice Generic helper contract that can yank ERC‑20 tokens from a delinquent
 *         borrower once they’ve granted unlimited allowance via `approve` or
 *         ERC‑2612 `permit`. Only whitelisted pool contracts may invoke
 *         `seize()` so attackers can’t grief users.
 */

import "@openzeppelin/contracts/access/Ownable2Step.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

// sample uses Ownable2Step (extra security when switching owner)
contract AssetSeizer is Ownable {
    using SafeERC20 for IERC20;

    constructor(address initialOwner) Ownable(initialOwner) {}

    /*//////////////////////////////////////////////////////////////
                               EVENTS
    //////////////////////////////////////////////////////////////*/
    event PoolAuthorized(address pool, bool status);
    event AssetsSeized(address indexed pool, address indexed token, address indexed from, uint256 amount);

    /*//////////////////////////////////////////////////////////////
                               STORAGE
    //////////////////////////////////////////////////////////////*/
    mapping(address => bool) public authorizedPool; // pool ⇒ allowed?

    /*//////////////////////////////////////////////////////////////
                             ADMIN ACTIONS
    //////////////////////////////////////////////////////////////*/

    /// @notice grant/revoke access for a lending pool that can call `seize()`
    function setPool(address pool, bool status) external onlyOwner {
        authorizedPool[pool] = status;
        emit PoolAuthorized(pool, status);
    }

    /*//////////////////////////////////////////////////////////////
                                CORE
    //////////////////////////////////////////////////////////////*/

    /// @notice pull `amount` of `token` from `from` into the calling pool.
    /// @dev caller must be an authorized pool and already know `from` has
    ///      approved this contract for at least `amount`.
    function seize(address token, address from, uint256 amount) external {
        require(authorizedPool[msg.sender], "not pool");
        IERC20(token).safeTransferFrom(from, msg.sender, amount);
        emit AssetsSeized(msg.sender, token, from, amount);
    }

    /// @notice convenience batch variant
    function batchSeize(
        address[] calldata tokens,
        address[] calldata froms,
        uint256[] calldata amounts
    ) external {
        require(tokens.length == froms.length && tokens.length == amounts.length, "len mismatch");
        require(authorizedPool[msg.sender], "not pool");

        for (uint256 i; i < tokens.length; ++i) {
            IERC20(tokens[i]).safeTransferFrom(froms[i], msg.sender, amounts[i]);
            emit AssetsSeized(msg.sender, tokens[i], froms[i], amounts[i]);
        }
    }
}
