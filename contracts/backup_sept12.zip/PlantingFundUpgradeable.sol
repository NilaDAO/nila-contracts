// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
 * PlantingFundUpgradeable ‑ v1.02
 v1.01
 * Single global lending pool that serves many "unions" (farmer co‑operatives).
 * ‑ Each union is identified by its address; deposits & borrows are isolated per‑union.
 * ‑ Borrower draws down a loan using an oracle‑signed Voucher, but can only:
 *      • LOWER the amount (≤ maxAmount)
 *      • RAISE the interest rate (≥ minInterestBP)
 * ‑ Borrow cap: totalBorrows ≤ 2 × historical‑max deposits for that {union,token}.
 * ‑ Interest accrues linearly by time‑elapsed (seconds) and stops at maturity
 *   (maturity = oracle‑reported harvest date + 6 weeks).
 * ‑ 1 % of every interest payment is skimmed to the `treasury` address.
 *
 * The contract is Upgradeable (UUPS) and uses OpenZeppelin upgradeable base‑contracts.
 v1.02 (JUN 22 ??)
 *  check union active on invest
 *  Added getBorrowCap ->           Returns the absolute borrow cap (2× historical max deposits)
 *  Added getRemainingBorrowCap     Returns how much more can be borrowed right now
 *  Added canBorrow                 Quick boolean check: “can I borrow `amount` more?
 *  Added location mapping for each union, 
 *  Updated activateUnion to carry location and set location mapping
 */

import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts-upgradeable/utils/cryptography/EIP712Upgradeable.sol";
import "@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";

// ──────────────────── external factory interface ────────────────────
interface IFundFactory {
    function registerFund(
        address unionAddr,
        address fundAddr,
        string calldata fundName,
        string calldata contractName
    ) external;
}

contract PlantingFundUpgradeable is Initializable,
                                     OwnableUpgradeable,
                                     PausableUpgradeable,
                                     ReentrancyGuardUpgradeable,
                                     UUPSUpgradeable,
                                     EIP712Upgradeable
{
    using SafeERC20 for IERC20Metadata;

    // ─────────────── constants ───────────────
    uint256 private constant RAY  = 1e27;           // 10^27 fixed‑point
    uint256 private constant YEAR = 365 days;
    uint256 private constant SIX_WEEKS = 42 days;
    uint16  private constant TREASURY_FEE_BP = 100; // 1 %

    // ─────────────── storage ───────────────
    address public treasury;                        // receives 1 % of all interest
    address public fundFactory;                     // external discovery hub

    mapping(address => bool)               public oracleSigners; // whitelisted oracles
    mapping(address => Union)              private unions;       // unionAddr ⇒ Union
    mapping(address => bytes32[])          public loansByBorrower;
    mapping(address => address[])          private unionTokens;
    mapping(address => string)             public unionLocation;

    // ─────────────── structs ───────────────

    struct Market {
        uint128 supplyIndex;   // RAY‑scaled (starts at 1e27)
        uint128 borrowIndex;   // reserved (not used yet)
        uint256 totalShares;   // lender shares (principal)
        uint256 totalBorrows;  // outstanding principal
        uint256 maxDeposited;  // running‑max of underlying deposits
    }

    struct InvestorInfo {
        uint256 shares;        // lender principal
        uint128 entryIndex;    // snapshot of supplyIndex
        uint128 unclaimed;     // interest accrued but not yet claimed
    }

    struct Loan {
        address borrower;      // borrower address
        address token;         // token address (e.g. USDC)
        uint128 principal;     // drawn principal
        uint16  rateBP;        // annual rate (basis points)
        uint40  drawdownTs;    // timestamp when funds sent
        uint40  harvestTs;     // set by oracle (0 until report)
        uint40  maturityTs;    // harvestTs + 6 weeks (0 until report)
        uint128 repaid;        // principal repaid
        uint128 interestPaid;  // interest paid so far
        bool    liquidated;    // true ⇒ default processed
    }

    struct Voucher {
        address borrower;
        address union;
        address token;
        uint256 maxAmount;
        uint16  minRateBP;
        uint256 nonce;
    }

    struct Union {
        string  name;
        bool    active;
        mapping(address => Market)         markets;     // token ⇒ Market
        mapping(address => InvestorInfo)   investors;   // lender ⇒ info (per default token)
        mapping(bytes32  => Loan)          loans;       // loanId ⇒ Loan
    }

    // ─────────────── EIP‑712 type hashes ───────────────
    // keccak256("Voucher(address borrower,address union,address token,uint256 maxAmount,uint16 minRateBP,uint256 nonce)")
    bytes32 private constant VOUCHER_TYPEHASH = 0x329e8d27e65c523cb0aff8c619f350c39037c13b6e9b99fb522a4a4a1c247f08;
    // keccak256("Harvest(bytes32 loanId,uint40 harvestDate)")
    bytes32 private constant HARVEST_TYPEHASH = 0x4a806021fd9a5ab2cd0e47e92593834c3b5821f2d7dd812ee55aa43d562e2ebd;

    // ─────────────── events ───────────────

    event TreasuryUpdated(address indexed newTreasury);
    event OracleSignerUpdated(address indexed signer, bool allowed);
    event UnionRegistered(address indexed unionAddr, string name);

    // savings
    event Invested(address indexed unionAddr, address indexed investor, address indexed token, uint256 amount, uint256 shares);
    event Withdrawn(address indexed unionAddr, address indexed investor, address indexed token, uint256 amount, uint256 shares);
    event InterestClaimed(address indexed unionAddr, address indexed investor, address indexed token, uint256 amount);

    // loans
    event LoanClaimed(address indexed unionAddr, bytes32 indexed loanId, address indexed borrower, address token, uint256 principal, uint16 rateBP);
    event HarvestReported(address indexed unionAddr, bytes32 indexed loanId, uint40 harvestTs, uint40 maturityTs);
    event LoanRepaid(address indexed unionAddr, bytes32 indexed loanId, address indexed borrower, uint256 amount, uint256 interestToLenders, uint256 interestToTreasury);
    event LoanLiquidated(address indexed unionAddr, bytes32 indexed loanId);

    // ─────────────── upgrade / init ───────────────

    function initialize(
        address _treasury,
        address _oracleSigner
        ) public initializer {
        require(_treasury != address(0), "treasury = zero");

        __Ownable_init(_oracleSigner);
        __Pausable_init();
        __ReentrancyGuard_init();
        __UUPSUpgradeable_init();
        __EIP712_init("PlantingFund", "1.0");


        treasury = _treasury;
        emit TreasuryUpdated(_treasury);
    }

    function _authorizeUpgrade(address /*impl*/) internal override onlyOwner {}

    // ─────────────── oracle / gov setters / union control ───────────────

    /// @notice Deactivate a union (owner only)
    function deactivateUnion(address unionAddr) external onlyOwner {
        Union storage u = unions[unionAddr];
        u.active = false;
    }

    /// @notice activate a union (owner only)
    function activateUnion(address unionAddr, string calldata location) external onlyOwner {
        Union storage u = unions[unionAddr];
        u.active = true;
        unionLocation[unionAddr] = location;
    }

    function setTreasury(address newTreasury) external onlyOwner {
        require(newTreasury != address(0), "treasury = zero");
        treasury = newTreasury;
        emit TreasuryUpdated(newTreasury);
    }

    function setOracleSigner(address signer, bool allowed) external onlyOwner {
        oracleSigners[signer] = allowed;
        emit OracleSignerUpdated(signer, allowed);
    }

    // ─────────────── saver side ───────────────

    function invest(address unionAddr, address token, uint256 amount) external whenNotPaused nonReentrant {
        require(amount > 0, "zero amount");
        Union storage u = unions[unionAddr];
        require(u.active, "union inactive");  // ADDED V1.02 - 22JUN - NOT YET PUSHED
        Market storage m = u.markets[token];

        // initialise supplyIndex to 1 RAY on first deposit
        if (m.supplyIndex == 0) m.supplyIndex = uint128(RAY);

        // pull tokens first (re‑entrancy safe thanks to nonReentrant)
        IERC20Metadata(token).safeTransferFrom(msg.sender, address(this), amount);

        uint256 shares = _underlyingToShares(amount, m.supplyIndex);
        m.totalShares  += shares;

        // update running max for borrow‑cap formula
        uint256 underlyingAfter = _sharesToUnderlying(m.totalShares, m.supplyIndex);
        if (underlyingAfter > m.maxDeposited) {
            m.maxDeposited = underlyingAfter;
        }

        // set token in unionTokens if not already present
        if (m.supplyIndex == 0) {
            m.supplyIndex = uint128(RAY);
            unionTokens[unionAddr].push(token);
        }

        // credit lender
        InvestorInfo storage info = u.investors[msg.sender];
        _accrueInvestor(info, m.supplyIndex);
        info.shares += shares;

        emit Invested(unionAddr, msg.sender, token, amount, shares);
    }

    function withdraw(address unionAddr, address token, uint256 shares) external whenNotPaused nonReentrant {
        Union storage u = unions[unionAddr];
        require(u.active, "union inactive");
        Market storage m = u.markets[token];
        require(m.supplyIndex != 0, "market empty");

        InvestorInfo storage info = u.investors[msg.sender];
        require(shares > 0 && shares <= info.shares, "invalid shares");

        _accrueInvestor(info, m.supplyIndex);
        info.shares -= shares;

        uint256 amountOut = _sharesToUnderlying(shares, m.supplyIndex);
        m.totalShares -= shares;

        IERC20Metadata(token).safeTransfer(msg.sender, amountOut);

        emit Withdrawn(unionAddr, msg.sender, token, amountOut, shares);
    }

    function claimInterest(address unionAddr, address token) external whenNotPaused nonReentrant {
        Union storage u = unions[unionAddr];
        require(u.active, "union inactive");
        Market storage m = u.markets[token];
        require(m.supplyIndex != 0, "market empty");

        InvestorInfo storage info = u.investors[msg.sender];
        _accrueInvestor(info, m.supplyIndex);

        uint256 payout = info.unclaimed;
        require(payout > 0, "no interest");
        info.unclaimed = 0;

        IERC20Metadata(token).safeTransfer(msg.sender, payout);
        emit InterestClaimed(unionAddr, msg.sender, token, payout);
    }

    // ─────────────── loan side ───────────────

    function claimLoan(
        Voucher   calldata v,
        uint256   chosenAmount,
        uint16    chosenRateBP,
        bytes     calldata sig
    ) external whenNotPaused nonReentrant {
        require(msg.sender == v.borrower, "not borrower");
        require(chosenAmount > 0 && chosenAmount <= v.maxAmount, "amount too high");
        require(chosenRateBP >= v.minRateBP, "interest too low");

        // verify oracle signature
        bytes32 digest = _hashTypedDataV4(keccak256(abi.encode(
            VOUCHER_TYPEHASH,
            v.borrower,
            v.union,
            v.token,
            v.maxAmount,
            v.minRateBP,
            v.nonce
        )));
        address signer = ECDSA.recover(digest, sig);
        require(oracleSigners[signer], "unauthorised oracle");

        // derive loanId (deterministic per voucher; replay safe)
        bytes32 loanId = keccak256(abi.encode(v));
        Union storage u = unions[v.union];
        require(u.loans[loanId].drawdownTs == 0, "loan exists");

        // borrow‑cap enforcement (≤ 2 × maxDeposited)
        Market storage m = u.markets[v.token];
        require(m.supplyIndex != 0, "market empty");
        uint256 newBorrows = m.totalBorrows + chosenAmount;
        require(newBorrows <= 2 * m.maxDeposited, "borrow cap exceeded");

        // write loan struct
        u.loans[loanId] = Loan({
            borrower:      v.borrower,
            token:         v.token,
            principal:     uint128(chosenAmount),
            rateBP:        chosenRateBP,
            drawdownTs:    uint40(block.timestamp),
            harvestTs:     0,
            maturityTs:    0,
            repaid:        0,
            interestPaid:  0,
            liquidated:    false
        });

        // set loanid to address dependend mapping
        loansByBorrower[msg.sender].push(loanId);

        // move funds to borrower
        m.totalBorrows = newBorrows;

        IERC20Metadata(v.token).safeTransfer(msg.sender, chosenAmount);

        emit LoanClaimed(v.union, loanId, msg.sender, v.token, chosenAmount, chosenRateBP);
    }

/**
     * @notice Repay a loan (principal + interest). Splits interest between lenders and treasury.
     * @param unionAddr The union under which the loan was issued
     * @param loanId The identifier of the loan
     * @param amount Amount being repaid (must cover at least interest due)
     */
    function repayLoan(
        address unionAddr,
        address token,
        bytes32 loanId,
        uint256 amount
    ) external whenNotPaused nonReentrant {
        Union storage u = unions[unionAddr];
        Market storage mkt;
        // find which market this loan's token belongs to by scanning markets? Assume loanId encodes token context
        // For simplicity, store token in Loan struct if needed. Here, assume token is known or fixed.
        // In production, Loan should include token; omitted for brevity.
        
        Loan storage ln = u.loans[loanId];
        require(ln.drawdownTs != 0, "loan does not exist");
        require(ln.harvestTs != 0, "harvest not reported");
        require(!ln.liquidated, "already liquidated");

        uint40 currentTs = uint40(block.timestamp);
        // calculate total owed: principal + interest accrued till min(currentTs, maturity)
        uint40 endTs = currentTs < ln.maturityTs ? currentTs : ln.maturityTs;
        uint256 elapsed = endTs - ln.drawdownTs;
        uint256 totalInterest = (uint256(ln.principal) * ln.rateBP * elapsed) / (10_000 * YEAR);
        uint256 totalOwed = uint256(ln.principal) + totalInterest;

        IERC20Metadata(token).safeTransferFrom(msg.sender, address(this), amount);
        ln.repaid += uint128(amount);

        // reduce totalBorrows
        mkt = u.markets[token];
        uint256 principalRecovery = amount > totalInterest ? amount - totalInterest : 0;
        if (mkt.totalBorrows >= principalRecovery) {
            mkt.totalBorrows -= principalRecovery;
        } else {
            mkt.totalBorrows = 0;
        }

        // distribute interest: 1% to treasury, rest to lenders
        uint256 interestToTreasury = (totalInterest * TREASURY_FEE_BP) / 10_000;
        uint256 interestToLenders = totalInterest - interestToTreasury;
        _creditInterest(mkt, token, interestToLenders);
        IERC20Metadata(token).safeTransfer(treasury, interestToTreasury);

        if (ln.repaid >= totalOwed) {
            ln.liquidated = true;
        }

        emit LoanRepaid(unionAddr, loanId, msg.sender, amount, interestToLenders, interestToTreasury);
    }

    // Oracle message: set harvest date (one‑shot)
    function reportHarvest(
        address unionAddr,
        bytes32 loanId,
        uint40 harvestDate
    ) external whenNotPaused {
        require(oracleSigners[msg.sender], "unauthorised oracle");
        Union storage u = unions[unionAddr];
        Loan storage ln = u.loans[loanId];
        require(ln.drawdownTs != 0, "loan does not exist");
        require(ln.harvestTs == 0, "harvest already reported");

        ln.harvestTs = harvestDate;
        ln.maturityTs = uint40(harvestDate + SIX_WEEKS);

        emit HarvestReported(unionAddr, loanId, ln.harvestTs, ln.maturityTs);
    }

    /*
     *  NOTE: To keep this example self‑contained and readable, the `reportHarvest`,
     *  `repayLoan`, and `liquidateLoan` functions are simplified placeholders.
     *  A production version should:
     *   ‑ include the unionAddr in the calldata to locate the Loan struct
     *   ‑ correctly update union.markets[token] accounting on principal repayment
     *   ‑ credit interest to lenders & treasury using _creditInterest(...)
     *   ‑ emit the remaining loan events.
     */

    // ─────────────── internal helpers ───────────────
    function supply(address union, address token) external view returns (uint256) {
        Market storage m = unions[union].markets[token];
        return (m.totalShares * m.supplyIndex) / RAY;
    }

    function _underlyingToShares(uint256 amount, uint256 supplyIndex) private pure returns (uint256) {
        // shares = amount × RAY / supplyIndex
        return (amount * RAY) / supplyIndex;
    }

    function _sharesToUnderlying(uint256 shares, uint256 supplyIndex) private pure returns (uint256) {
        return (shares * supplyIndex) / RAY;
    }

    /// @notice Helper to check if an address is whitelisted as an oracle signer
    function isOracleSigner(address signer) external view returns (bool) {
        return oracleSigners[signer];
    }

    /// @notice Recover the signer for a given Voucher and signature
    function recoverVoucherSigner(
        Voucher calldata v,
        bytes     calldata sig
    ) external view returns (address) {
        bytes32 digest = _hashTypedDataV4(
            keccak256(abi.encode(
                VOUCHER_TYPEHASH,
                v.borrower,
                v.union,
                v.token,
                v.maxAmount,
                v.minRateBP,
                v.nonce
            ))
        );
        return ECDSA.recover(digest, sig);
    }

    function _accrueInvestor(InvestorInfo storage info, uint256 currentSupplyIndex) private {
        if (info.shares == 0) {
            info.entryIndex = uint128(currentSupplyIndex);
            return;
        }
        uint256 deltaIndex = currentSupplyIndex - info.entryIndex; // both RAY‑scaled
        uint256 pending    = (info.shares * deltaIndex) / RAY;
        info.unclaimed    += uint128(pending);
        info.entryIndex    = uint128(currentSupplyIndex);
    }

    // placeholder for interest crediting to lenders & treasury
    function _creditInterest(
        Market   storage m,
        address  token,
        uint256  interest
    ) private {
        if (interest == 0) return;

        uint256 fee  = (interest * TREASURY_FEE_BP) / 10_000;
        uint256 toLm = interest - fee;

        // add to pool & update index
        if (m.totalShares == 0) {
            // no lenders: treat as protocol revenue -> treasury
            IERC20Metadata(token).safeTransfer(treasury, toLm);
        } else {
            uint256 addShares = _underlyingToShares(toLm, m.supplyIndex);
            m.totalShares += addShares;
            // supplyIndex' = supplyIndex + toLm × RAY / totalShares'
            m.supplyIndex = uint128(m.supplyIndex + (toLm * RAY) / m.totalShares);
        }
    }
    /*//////////////////////////////////////////////////////////////
                               VIEWS
    //////////////////////////////////////////////////////////////*/
    
    /// @notice add a no-op canary
    function version() external pure returns (string memory) {
    return "v1.02";
    }

    /// @notice Retrieve all loan IDs for a given borrower
    function getLoansByBorrower(address borrower) external view returns (bytes32[] memory) {
        return loansByBorrower[borrower];
    }
    /**
     * DEV NOTE: INPUTFUND HAS DIFFERENT STRUCTURE, DOESNT REQUIRE UNION ADDRESS, UPDATE ACCORDINGLY
     */
    /// @notice Returns all token addresses a union has ever invested
    function getTokenList(address unionAddr)
        external view
        returns (address[] memory)
        {
        return unionTokens[unionAddr];
        }

    /// @notice For a given union & token, returns total underlying deposited and total outstanding borrows
    function getFundTotals(address unionAddr, address token)
        external view
        returns (uint256 totalDeposits, uint256 totalBorrows)
        {
        Market storage m = unions[unionAddr].markets[token];
        totalDeposits = _sharesToUnderlying(m.totalShares, m.supplyIndex);
        totalBorrows  = m.totalBorrows;
        }
    
    /// @notice Returns (shares, pendingInterest, isFrozen) for any lender in a union/token
    function getInvestorInfo(
        address unionAddr,
        address token,
        address investorAddr
    ) external view
        returns (uint256 shares, uint256 pending, bool isFrozen) {
            Union storage u = unions[unionAddr];
            Market storage m = u.markets[token];
            InvestorInfo storage info = u.investors[investorAddr];
            // accrue on-the-fly
            uint256 delta = m.supplyIndex - info.entryIndex;
            uint256 accrued = (info.shares * delta) / RAY;
            shares   = info.shares;
            pending  = info.unclaimed + accrued;
            isFrozen = false;
        }
    
    function getBorrowerInfo(
        address unionAddr,
        bytes32 loanId
    ) external view
        returns (
            address borrower,
            address token,
            uint256 principal,
            uint256 repaid,
            uint16  rateBP,
            uint40  dueDate,
            bool    closed,
            uint256 outstanding,
            bool    isFrozen,
            bool    poolInsolvent
        )
        {
        Loan storage ln = unions[unionAddr].loans[loanId];
        borrower       = ln.borrower;         // you’ll need to store this in claimLoan
        token          = ln.token;            // likewise store token on claimLoan
        principal      = ln.principal;
        repaid         = ln.repaid;
        rateBP         = ln.rateBP;
        dueDate        = ln.maturityTs;
        closed         = ln.liquidated;
        // simple outstanding = principal + accrued interest − repaid
        {
            uint40 nowOrMat = ln.maturityTs == 0 ? uint40(block.timestamp) : ln.maturityTs;
            uint256 elapsed= uint256(nowOrMat - ln.drawdownTs);
            uint256 interest = (uint256(ln.principal) * rateBP * elapsed) / (10_000 * YEAR);
            outstanding = principal + interest - repaid;
        }
        isFrozen       = false;
        poolInsolvent  = false;
        }

    /// @notice Returns the absolute borrow cap (2× historical max deposits)
    function getBorrowCap(address unionAddr, address token)
        external
        view
        returns (uint256 cap)
        {
            Market storage m = unions[unionAddr].markets[token];
            cap = 2 * m.maxDeposited;
        }

    /// @notice Returns how much more can be borrowed right now:
    /// (i.e. borrowCap − totalBorrows, or zero if fully tapped)
    function getRemainingBorrowCap(address unionAddr, address token)
        external
        view
        returns (uint256 remaining)
        {
            Market storage m = unions[unionAddr].markets[token];
            uint256 cap = 2 * m.maxDeposited;
            remaining = cap > m.totalBorrows
            ? cap - m.totalBorrows
            : 0;
        }

    /// @notice Quick boolean check: “can I borrow `amount` more?”
    function canBorrow(address unionAddr, address token, uint256 amount)
        external
        view
        returns (bool)
        {
            Market storage m = unions[unionAddr].markets[token];
            return (m.totalBorrows + amount) <= (2 * m.maxDeposited);
        }

    /*//////////////////////////////////////////////////////////////
                            UPGRADEABLE GAP
    //////////////////////////////////////////////////////////////*/

    uint256[29] private __gap;


}
