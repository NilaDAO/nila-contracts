// SPDX-License-Identifier: MIT
pragma solidity ^0.8.25;

/*
 * Shared Cropping Upgradeable Contract (scaffold)
 * ------------------------------------------------
 * Implements:
 * 0. Nested mapping of interested landIds per union address + getter
 * 1. Cohort proposals by ORACLE_ROLE stored on‑chain (metadata via URI)
 * 2. Farmer enrolment by escrowing an ERC‑1155 Food Token
 * 3. Monthly voucher payouts constrained by oracle‑signed limits
 * 4. Farmer‑initiated dispute sampling peer review (placeholder)
 * 5. Harvest finalisation & payout distribution once conditions met
 *
 * NOTE: This is a functional scaffold to compile & test in Hardhat.
 *       Further business‑logic details (peer‑selection, field visits, fee maths)
 *       can be added in later upgrades via UUPS.
 */

import "@openzeppelin/contracts-upgradeable/access/AccessControlUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol";
import "@openzeppelin/contracts-upgradeable/proxy/utils/UUPSUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/token/ERC1155/utils/ERC1155HolderUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/PausableUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/ReentrancyGuardUpgradeable.sol";
import "@openzeppelin/contracts-upgradeable/utils/cryptography/EIP712Upgradeable.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/token/ERC1155/IERC1155.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC721/IERC721.sol";

/* -------------------- Extended Lending interface ------------------- */
interface IUnionLending {
    function getInvestorInfo(
        address unionAddr,
        address token,
        address investorAddr
    )
        external
        view
        returns (
            uint256 shares,
            uint256 pending,
            bool    isFrozen
        );
}

/* -------------------- Extended FoodToken interface ------------------- */
interface IFoodToken is IERC1155 {
    /// @notice ERC-1155 balanceOf
    function balanceOf(address account, uint256 id) external view returns (uint256);
    /// @notice ERC-1155 safeTransferFrom
    function safeTransferFrom(address from,address to,uint256 id,uint256 amount,bytes calldata data) external;
    function mint(address to, uint256 id, uint256 amount, bytes calldata data) external;
    function burn(address from, uint256 id, uint256 amount) external;
    function setURI(uint256 id, string calldata newuri) external;
}


contract SharedCroppingUpgradeable is
    Initializable,
    PausableUpgradeable,
    ReentrancyGuardUpgradeable,
    AccessControlUpgradeable,
    UUPSUpgradeable,
    EIP712Upgradeable,
    ERC1155HolderUpgradeable
{    
    using ECDSA for bytes32;

    // ------------------------------------------------------------------
    // Constants & Storage
    // ------------------------------------------------------------------

    // ---------------- Roles ----------------
    bytes32 public constant ORACLE_ROLE = keccak256("ORACLE_ROLE");

    // ---------------- External Tokens ----------------
    IFoodToken public foodToken;    // collateral token (ERC‑1155)
    IERC721  public landTitle;    // Land title NFT registry (ERC-721)
    IERC20   public nIN;          // INR‑pegged stablecoin (ERC‑20)
    address  public treasury;     // address that receives pool repayments / fees
    address  public oracle;       // oracle address
    IUnionLending public funding; // lending pool interface
    uint256  private _nextCohortId;
    uint256  public cohortProposalFee; // fee to suggest a proposal
    address[] public unions;

    mapping(uint256 => CohortProposal) public cohorts; // id => proposal
    mapping(address => uint32[]) private availableLand;  // unionAddr => list of interested landIds
    mapping(uint256 => FarmerInfo) public farmerByToken;  // tokenId => FarmerInfo
    mapping(uint256 => SaleInfo) public sales;

    /* ---------------- EIP‑712 ---------------- */
    bytes32 private constant VOUCHER_TYPEHASH = keccak256("StipendVoucher(uint256 amount)");

    // ─────────────── structs ───────────────
    struct CohortProposal {
        uint256 id;               // unique id
        string uri;               // IPFS or off‑chain JSON with full economics (crop, costs, etc.)
        uint256 logisticsCost;    // union logistics fee (wei)
        uint256 inputsCost;       // union input fee (wei)
        uint256 handlingFee;      // union handling fee (wei)
        uint256 contractFee;      // platform fee (wei)
        uint256 minShares;        // minimum shares the participant in the cohort should have locked
        uint256[] landIds;        // list of landIds matched into cohort
        address proposer;
        address union;
        }

    struct FarmerInfo {
        address union;
        address farmer;
        uint256 tokenId;           // deposited ERC‑1155 tokenId
        uint256 cohortId;
        uint256 totalDrawn;        // running sum of monthly withdrawals
        uint256 depositedTokens;
        }

    struct SaleInfo {
        uint256 soldAmount;   // tokens transferred to buyers so far
        uint256 totalRevenue; // nIN collected
    }

    struct StipendVoucher {
        uint256 amount;
    }

    struct CohortSettle {
        uint256 cohortId;
        bytes32 stateHash;
    }
    
    // ------------------------------------------------------------------
    // Events
    // ------------------------------------------------------------------

    event LandInterestAdded(address indexed union, uint256 landId, address indexed caller);
    event UnionAddedToProgam(address indexed union);

    event CohortProposed(uint256 indexed cohortId, string uri, uint32[] landIds);
    event CohortUpdated(uint256 indexed cohortId, string newUri);
    event CohortDeactivated(uint256 indexed cohortId);

    event FoodTokenDeposited(uint256 indexed tokenId, uint256 indexed cohortId, address indexed farmer, uint256 voucherCap);
    event VoucherDisputed(uint256 indexed tokenId, address indexed farmer);

    event HarvestRecorded(uint256 indexed tokenId, uint256 yieldQty, uint256 quality);
    event CohortFinalised(uint256 cohortId);
    event BulkSale(uint256[] tokenIds, address buyer, uint256 totalCost, uint256 unitPrice);

    // ------------------------------------------------------------------
    // Initializer
    // ------------------------------------------------------------------
    function initialize(
        address oracleAddr,
        address _foodToken,
        address _nIN,
        address _landTitle,
        address _treasury,
        address _investorPool    
    ) external initializer {
        __AccessControl_init();
        __UUPSUpgradeable_init();
        __ERC1155Holder_init();

        _grantRole(ORACLE_ROLE, oracleAddr);
        treasury = _treasury;
        funding = IUnionLending(_investorPool);
        foodToken = IFoodToken(_foodToken);        
        nIN = IERC20(_nIN);
        landTitle = IERC721(_landTitle);
        oracle = oracleAddr;
    }

    // ---------------- Phase‑0 : Program interest ----------------

    /// @notice called by oracle to signup a union for sharedcropping program 
    /// getter - unionHasSharedCroppingProgram(address unionAddr)
    function registerUnionToProgram(address unionAddr) external {
        require(availableLand[unionAddr].length == 0, "already registered");
        unions.push(unionAddr);        
        emit UnionAddedToProgam(unionAddr);
    }

    /// @notice called by land owners to register interest in the program
    function registerInterest(address unionAddr, uint32 landId) external {
        require(landTitle.ownerOf(landId) == msg.sender, "caller not land owner");
        uint32[] storage arr = availableLand[unionAddr];
        for (uint32 i = 0; i < arr.length; i++) {
            require(arr[i] != landId, "land already registered");
        }
        arr.push(landId);
        emit LandInterestAdded(unionAddr, landId, msg.sender);
    }

    // ---------------- Phase‑1 : Cohort Proposal ----------------
    // New cohort proposed based on union market data (no sender limitation, only fee that has to be paid)
    function proposeCohort(
        string calldata uri,
        address union,
        uint256 logisticsCost,
        uint256 inputsCost,
        uint256 handlingFee,
        uint256 contractFee,
        uint256 minShares, // should be calculated offline as grow months * base amount, you dont want farmers to have locked in less (which means ie sugarcane growers need much higher cap)
        uint32[] calldata landIds
        ) external returns (uint256 cohortId) {
            require(landIds.length > 0, "empty landIds");        // Collect fee first (if set)
            if (cohortProposalFee > 0) {
                require(nIN.transferFrom(msg.sender, treasury, cohortProposalFee), "fee transfer failed");
            }
            cohortId = ++_nextCohortId;
            CohortProposal storage cp = cohorts[cohortId];
            cp.id = cohortId;
            cp.uri = uri;
            cp.logisticsCost = logisticsCost;
            cp.inputsCost = inputsCost;
            cp.handlingFee = handlingFee;
            cp.contractFee = contractFee;
            cp.minShares = minShares;
            cp.union = union;

            // copy land ids into storage
            cp.landIds = landIds;
            emit CohortProposed(cohortId, uri, landIds);
    }

    /// oracle can update metadata URI or cost figures anytime
    function updateCohortURI(uint256 cohortId, string calldata newUri) external onlyRole(ORACLE_ROLE) {
        CohortProposal storage cp = cohorts[cohortId];
        cp.uri = newUri;
        emit CohortUpdated(cohortId, newUri);
    }

    /** Admin can change the proposal fee */
    function setCohortProposalFee(uint256 newFee) external onlyRole(ORACLE_ROLE) {
        cohortProposalFee = newFee;
    }

    /// getter to view current fee
    function getCurrentFee() external view returns (uint256 fee) {
        return cohortProposalFee;
    }

    // ---------------- Phase‑2+ : Farmer Enrollment & Finance ----------------
    /// @notice Farmer escrows food token + oracle signed voucher cap to enrol in cohort
    function enrollByDeposit(
        address unionAddress,
        uint256 amount,
        uint256 cohortId,
        uint256 tokenId,
        uint256 voucherCap
        ) external {
        CohortProposal storage cp = cohorts[cohortId];
        // check if token already enrolled
        require(farmerByToken[tokenId].farmer == address(0), "token already used");
        // check if invested shares is enough to cover montly stipend
        if (cp.minShares > 0) {
            (uint256 shares,,) = funding.getInvestorInfo(unionAddress, address(nIN), msg.sender);
            require(shares >= cp.minShares, "insufficient pool shares");
        }
        // check if the ERC1155 food token is the farmers entire balance
        uint256 bal = foodToken.balanceOf(msg.sender, tokenId);
        require(amount == bal, "must deposit full token balance");

        // transfer token from farmer into contract
        // we keep minimal as a record in the front-end (signals possible lock)
        foodToken.safeTransferFrom(msg.sender, address(this), tokenId, bal - 1, bytes(""));
        // store farmer info
        farmerByToken[tokenId] = FarmerInfo({
            union: unionAddress,
            farmer: msg.sender,
            tokenId: tokenId,
            cohortId: cohortId,
            totalDrawn: 0,
            depositedTokens: bal - 1
        });
        emit FoodTokenDeposited(tokenId, cohortId, msg.sender, voucherCap);
    }

    function _hashVoucher(StipendVoucher memory v) private view returns (bytes32) {
        return _hashTypedDataV4(keccak256(abi.encode(
                VOUCHER_TYPEHASH,
                v.amount
            )));
    }

    /// @notice oracle signed voucher withdrawal (simplified hash check placeholder)
    function takeStipend(StipendVoucher calldata v,bytes calldata sig,uint256 tokenId, address unionAddress) 
        external
        whenNotPaused
        nonReentrant 
        {
        // check if the caller is the farmer self
        FarmerInfo storage fi = farmerByToken[tokenId];
        require(msg.sender == fi.farmer, "not farmer");
        uint256 totalAmount = fi.totalDrawn + v.amount;

        // check if voucher is genuine
        bytes32 digest = _hashVoucher(v);
        address signer = digest.recover(sig);
        require(oracle == signer, "unauthorised signer");

        // double check if the total (amount + already drawn) does not supercede the invested amount
        (uint256 shares,,) = funding.getInvestorInfo(unionAddress, address(nIN), msg.sender);
        require(shares >= totalAmount, "insufficient pool shares");

        // all fine, send the stipend and raise totalDrawn
        fi.totalDrawn += v.amount;
        require(nIN.transfer(fi.farmer, v.amount), "nIN transfer fail");
    }


    // ---------------- Phase‑3 : Harvest ----------------
    /**
     * union records harvest; also syncs foodToken supply & uri
     * @param finalizedUri  IPFS link with final quality certificate
     */
    function processHarvest(
        uint256 tokenId,
        uint256 yieldQty,
        uint256 quality,
        string calldata finalizedUri
        ) external {
        FarmerInfo storage fi = farmerByToken[tokenId];
        require(msg.sender == fi.union, "you are not the union of this cohort");

        // Update token metadata
        // MISSING THE TOKENID!! CANT BE CALLED
        foodToken.setURI(tokenId,finalizedUri); 

        // Sync supply: burn or mint to match actual yield
        if (yieldQty < fi.depositedTokens) {
            uint256 burnAmt = fi.depositedTokens - yieldQty;
            foodToken.burn(address(this), tokenId, burnAmt);
        } else if (yieldQty > fi.depositedTokens) {
            uint256 mintAmt = yieldQty - fi.depositedTokens;
            foodToken.mint(address(this), tokenId, mintAmt, "");
        }

        emit HarvestRecorded(tokenId, yieldQty, quality);
    }

    // ---------------- Phase‑4 : Dispute arrangement ----------------
    /// @notice farmer can dispute voucher amounts (placeholder event)
    function disputeVoucher(uint256 tokenId) external {
        FarmerInfo storage fi = farmerByToken[tokenId];
        require(msg.sender == fi.farmer, "not farmer");
        emit VoucherDisputed(tokenId, msg.sender);
        // off‑chain peer review logic handled externally; contract just logs
    }
    
    // ---------------- Final Distribution ----------------

    /**
     * Buyer purchases part of the yield (food tokens) by paying nIN.
     */
    function tokenSaleBatch(uint256[] calldata tokenIds, uint256 unitPrice) external {
        require(tokenIds.length > 0, "empty list");
        uint256 totalCost = 0;
        uint256[] memory amounts = new uint256[](tokenIds.length);

        // First loop – compute cost & collect totals
        for (uint256 i; i < tokenIds.length; ++i) {
            uint256 id = tokenIds[i];
            FarmerInfo storage fi = farmerByToken[id];
            uint256 available = fi.depositedTokens - sales[id].soldAmount;
            require(available > 0, "already sold");
            amounts[i] = available;
            totalCost += available;
        }
        // Pull payment once
        uint256 total = totalCost * unitPrice;
        require(nIN.transferFrom(msg.sender, address(this), total), "payment fail");

        // Second loop – transfer tokens & record revenue
        for (uint256 i; i < tokenIds.length; ++i) {
            uint256 id = tokenIds[i];
            uint256 amt = amounts[i];
            foodToken.safeTransferFrom(address(this), msg.sender, id, amt, "");
            sales[id].soldAmount   += amt;
            sales[id].totalRevenue += amt * unitPrice;
        }
         emit BulkSale(tokenIds, msg.sender, totalCost, unitPrice);
    }

    /**
     * @param cohortId  cohort being settled
     */
    function finalizeCohort(uint256 cohortId) external {
        // Only the oracle or the union itself can trigger settlement
        require(
            hasRole(ORACLE_ROLE, msg.sender),
            "only oracle can send this call (build bot to gather signatures, if > 50%, call finalize)"
        );

        CohortProposal storage c = cohorts[cohortId];
        uint256 farmerCount = c.landIds.length;
        require(farmerCount > 0, "no farmers");

        // ──────────────────────────────────────────────────
        // 1. Aggregate revenue that has actually arrived
        // ──────────────────────────────────────────────────
        uint256 totalRevenue;          // nIN that came in through on‑chain sales
        for (uint256 i; i < farmerCount; ++i) {
            uint256 id = c.landIds[i];
            SaleInfo storage s = sales[id];
            totalRevenue += s.totalRevenue; // zero if tokenId was never sold on‑chain
        }
        require(totalRevenue > 0, "no revenue recorded");
        require(nIN.balanceOf(address(this)) >= totalRevenue, "we dont have enough nIN in the wallet, what happened?");

        // Total cohort‑level fees (fixed rupee amounts set when cohort proposed)
        uint256 totalFees = c.logisticsCost + c.inputsCost + c.handlingFee;
        uint256 totalContract = c.contractFee;

        // ──────────────────────────────────────────────────
        // 2. Pay each farmer:  (their revenue share) ‑ (pro‑rata fees) ‑ (already drawn)
        // ──────────────────────────────────────────────────
        uint256 totalPaid = 0;
        for (uint256 i; i < farmerCount; ++i) {
            uint256 id = c.landIds[i];
            FarmerInfo storage fi = farmerByToken[id];

            uint256 gross = sales[id].totalRevenue; // farmer's own sale revenue
            if (gross == 0) continue;          // skip if not sold on‑chain

            // Pro‑rata fee share = gross / totalRevenue * totalFees
            uint256 feeShare = (gross * totalFees) / totalRevenue;

            uint256 net = gross > feeShare ? gross - feeShare : 0;
            // subtract monthly stipends already drawn
            if (net > fi.totalDrawn) net -= fi.totalDrawn; else net = 0;

            if (net > 0) nIN.transfer(fi.farmer, net);
            // accumute paid
            totalPaid += net;

            // cleanup per‑farmer temp data
            delete sales[id];
            delete farmerByToken[id];
        }

        // ──────────────────────────────────────────────────
        // 3. Send cost and profits to the union 
        // ──────────────────────────────────────────────────
        address union = cohorts[cohortId].union;
        if (totalFees > 0) nIN.transfer(union, totalFees);

        // ──────────────────────────────────────────────────
        // 4. Send remaining nIN (the fee pool) to treasury 
        // ──────────────────────────────────────────────────
        uint256 remaining = totalRevenue - totalFees - totalPaid + totalContract;
        if (remaining >= 0) nIN.transfer(treasury, remaining);

        // cleanup cohort data
        delete cohorts[cohortId];

        emit CohortFinalised(cohortId);
    }

    // ---------------- ERC1155Receiver ----------------
    function onERC1155Received(
        address,
        address,
        uint256,
        uint256,
        bytes memory
    ) public pure override returns (bytes4) {
        return this.onERC1155Received.selector;
    }

    function onERC1155BatchReceived(
        address,
        address,
        uint256[] memory,
        uint256[] memory,
        bytes memory
    ) public pure override returns (bytes4) {
        return this.onERC1155BatchReceived.selector;
    }

    // ---------------- Upgradeability ----------------
    function _authorizeUpgrade(address newImpl) internal override onlyRole(ORACLE_ROLE) {}

    // ---------------- supportsInterface override ----------------
    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(AccessControlUpgradeable, ERC1155HolderUpgradeable)
        returns (bool)
    {
        return super.supportsInterface(interfaceId);
    }

    // ------------------------------------------------------------------
    // Metadata & Views
    // ------------------------------------------------------------------

    /// @notice hash helper for off‑chain voucher signing tools
    function getVoucherDigest(StipendVoucher calldata v) external view returns (bytes32) {
        return _hashVoucher(v);
    }

    /// @dev getter returns copy of landId list for a union
    function getInterestedLand(address unionAddr) external view returns (uint32[] memory) {
        return availableLand[unionAddr];
    }

    // ------------------------------------------------------------------
    // Storage gap
    // ------------------------------------------------------------------

    uint256[46] private __gap;
}
